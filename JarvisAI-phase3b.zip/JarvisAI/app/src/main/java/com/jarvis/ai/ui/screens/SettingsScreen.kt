package com.jarvis.ai.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.database.PrefEntity
import com.jarvis.ai.models.JarvisLanguage
import com.jarvis.ai.models.JarvisUiState
import com.jarvis.ai.ui.components.HoloPanel
import com.jarvis.ai.ui.theme.JarvisColors

@Composable
fun SettingsScreen(
    ui: JarvisUiState,
    memory: List<PrefEntity>,
    onLanguage: (JarvisLanguage) -> Unit,
    onUkVoice: (Boolean) -> Unit,
    onCloudVoice: (Boolean) -> Unit,
    onPitch: (Float) -> Unit,
    onRate: (Float) -> Unit,
    onSaveVoice: () -> Unit,
    onCycleVoice: () -> Unit,
    onTestVoice: () -> Unit,
    onSaveBackend: (String, String) -> Boolean,
    onClearMemory: () -> Unit,
    onClearHistory: () -> Unit
) {
    val context = LocalContext.current
    var confirmClear by remember { mutableStateOf(false) }
    var confirmClearMemory by remember { mutableStateOf(false) }
    var url by remember(ui.backendUrl) { mutableStateOf(ui.backendUrl) }
    var token by remember(ui.backendToken) { mutableStateOf(ui.backendToken) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("SETTINGS", color = JarvisColors.Cyan, fontSize = 20.sp, letterSpacing = 4.sp)

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Voice recognition language", color = JarvisColors.Text, fontSize = 14.sp)
            Text(
                "Hindi mode also understands English words (Hinglish). Commands work in both languages.",
                color = JarvisColors.CyanDim, fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisLanguage.values().forEach { lang ->
                    if (lang == ui.language) {
                        Button(onClick = { onLanguage(lang) }) { Text(lang.label) }
                    } else {
                        OutlinedButton(onClick = { onLanguage(lang) }) { Text(lang.label) }
                    }
                }
            }
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("JARVIS voice", color = JarvisColors.Text, fontSize = 14.sp)
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Natural JARVIS voice (AI backend)", color = JarvisColors.CyanDim, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(checked = ui.cloudVoice, onCheckedChange = onCloudVoice)
            }
            Text(
                "Needs the AI backend below. If it is off or fails, the phone's own voice is used, and the pitch, speed and voice settings here apply to that voice.",
                color = JarvisColors.CyanDim, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp)
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("British English (UK) voice", color = JarvisColors.CyanDim, fontSize = 12.sp)
                Switch(checked = ui.ukVoice, onCheckedChange = onUkVoice)
            }
            Text("Pitch (lower = deeper): ${"%.2f".format(ui.pitch)}", color = JarvisColors.CyanDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Slider(value = ui.pitch, onValueChange = onPitch, valueRange = 0.5f..1.2f, onValueChangeFinished = onSaveVoice)
            Text("Speed: ${"%.2f".format(ui.speechRate)}", color = JarvisColors.CyanDim, fontSize = 12.sp)
            Slider(value = ui.speechRate, onValueChange = onRate, valueRange = 0.6f..1.2f, onValueChangeFinished = onSaveVoice)
            Text(
                "Voice: ${ui.voiceName.ifBlank { "automatic" }}",
                color = JarvisColors.CyanDim, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCycleVoice) { Text("Change voice") }
                OutlinedButton(onClick = onTestVoice) { Text("Test voice") }
            }
            Text(
                "Tip: keep pressing Change voice until you find a deep male one.",
                color = JarvisColors.CyanDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("AI brain (Gemini via your backend)", color = JarvisColors.Text, fontSize = 14.sp)
            Text(
                if (ui.backendUrl.isBlank()) "OFF - only built-in commands work" else "ON",
                color = if (ui.backendUrl.isBlank()) JarvisColors.Amber else JarvisColors.Cyan,
                fontSize = 11.sp, letterSpacing = 1.sp, modifier = Modifier.padding(vertical = 4.dp)
            )
            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                label = { Text("Backend URL (https://...)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = token,
                onValueChange = { token = it },
                label = { Text("App token") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            Button(
                onClick = {
                    val ok = onSaveBackend(url, token)
                    Toast.makeText(
                        context,
                        if (ok) "Saved" else "URL must start with https://",
                        Toast.LENGTH_SHORT
                    ).show()
                },
                modifier = Modifier.padding(top = 8.dp)
            ) { Text("Save") }
            Text(
                "The Gemini API key never goes in this app. It stays on your backend. Leave the URL blank to turn the AI brain off.",
                color = JarvisColors.CyanDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Remembered preferences", color = JarvisColors.Text, fontSize = 14.sp)
            if (memory.isEmpty()) {
                Text("Nothing remembered yet.", color = JarvisColors.CyanDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            } else {
                memory.forEach {
                    Text(
                        "${it.key.removePrefix("mem:")}: ${it.value}",
                        color = JarvisColors.Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                }
                OutlinedButton(
                    onClick = { confirmClearMemory = true },
                    border = BorderStroke(1.dp, JarvisColors.Red),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisColors.Red),
                    modifier = Modifier.padding(top = 8.dp)
                ) { Text("Forget everything") }
            }
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Data", color = JarvisColors.Text, fontSize = 14.sp)
            OutlinedButton(
                onClick = { confirmClear = true },
                border = BorderStroke(1.dp, JarvisColors.Red),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisColors.Red),
                modifier = Modifier.padding(top = 8.dp)
            ) { Text("Clear command history") }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Delete command history?") },
            text = { Text("This permanently removes all saved commands from this phone.") },
            confirmButton = {
                TextButton(onClick = { confirmClear = false; onClearHistory() }) {
                    Text("Delete", color = JarvisColors.Red)
                }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }

    if (confirmClearMemory) {
        AlertDialog(
            onDismissRequest = { confirmClearMemory = false },
            title = { Text("Forget remembered preferences?") },
            text = { Text("JARVIS will no longer remember what it learned about you.") },
            confirmButton = {
                TextButton(onClick = { confirmClearMemory = false; onClearMemory() }) {
                    Text("Forget", color = JarvisColors.Red)
                }
            },
            dismissButton = { TextButton(onClick = { confirmClearMemory = false }) { Text("Cancel") } }
        )
    }
}
