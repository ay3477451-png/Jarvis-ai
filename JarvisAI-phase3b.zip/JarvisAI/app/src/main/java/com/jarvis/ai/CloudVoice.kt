package com.jarvis.ai

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

/**
 * JARVIS's natural voice: your backend turns text into speech with Gemini TTS (raw 24 kHz PCM)
 * and this class plays it. If anything fails, the engine falls back to the phone's own voice.
 */
class CloudVoice {

    suspend fun fetch(baseUrl: String, token: String, text: String): Result<ByteArray> =
        withContext(Dispatchers.IO) {
            try {
                require(baseUrl.startsWith("https://")) { "Backend URL must start with https://" }
                val conn = (URL(baseUrl.trimEnd('/') + "/tts").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 10_000
                    readTimeout = 45_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $token")
                }
                try {
                    val body = JSONObject().put("text", text.take(400)).toString()
                    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    if (code !in 200..299) error("voice backend returned $code")
                    val pcm = Base64.decode(JSONObject(response).getString("audio"), Base64.DEFAULT)
                    Result.success(pcm)
                } finally {
                    conn.disconnect()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /** Plays 16-bit mono 24 kHz PCM and returns when finished. Cancelling the coroutine stops it. */
    suspend fun play(pcm: ByteArray): Boolean = withContext(Dispatchers.IO) {
        var track: AudioTrack? = null
        try {
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(pcm.size)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(pcm, 0, pcm.size)
            track.play()
            val totalFrames = pcm.size / 2
            while (coroutineContext.isActive &&
                track.playState == AudioTrack.PLAYSTATE_PLAYING &&
                track.playbackHeadPosition < totalFrames
            ) {
                delay(50)
            }
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        } finally {
            runCatching { track?.stop() }
            runCatching { track?.release() }
        }
    }

    private companion object {
        const val SAMPLE_RATE = 24_000
    }
}
