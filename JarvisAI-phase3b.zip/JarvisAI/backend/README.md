# JARVIS AI backend (Cloudflare Worker, free)

Gives JARVIS (1) a Gemini brain for free conversation and multi-step commands and
(2) a natural deep voice (Gemini TTS). Your Gemini key stays here, never inside the app.

1. Get a Gemini API key: aistudio.google.com/app/apikey
2. dash.cloudflare.com > Workers & Pages > Create > Hello World > Deploy, then "Edit code".
   Delete everything, paste cloudflare-worker.js, click Deploy.
3. Worker > Settings > Variables and Secrets > add two SECRETS:
   GEMINI_API_KEY = your Gemini key
   APP_TOKEN      = a long random password you invent
   Optional variables: GEMINI_MODEL, GEMINI_TTS_MODEL, GEMINI_TTS_VOICE (try Charon, Orus, Alnilam, Algenib).
4. Copy the worker URL (https://something.workers.dev).
5. In the app: Settings > AI brain: paste the URL and the same APP_TOKEN, tap Save.
Open the worker URL in a browser: it should show "JARVIS backend online".
