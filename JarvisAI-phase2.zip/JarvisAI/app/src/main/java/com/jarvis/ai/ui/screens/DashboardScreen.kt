package com.jarvis.ai.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.database.HistoryEntity
import com.jarvis.ai.models.JarvisState
import com.jarvis.ai.models.JarvisUiState
import com.jarvis.ai.ui.components.ArcReactor
import com.jarvis.ai.ui.components.HoloPanel
import com.jarvis.ai.ui.components.MicButton
import com.jarvis.ai.ui.components.StatusPill
import com.jarvis.ai.ui.components.VoiceWaveform
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.utils.TimeUtils

@Composable
fun DashboardScreen(
    ui: JarvisUiState,
    level: Float,
    history: List<HistoryEntity>,
    onMic: () -> Unit,
    onEmergencyStop: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("J.A.R.V.I.S", color = JarvisColors.Cyan, fontSize = 28.sp, letterSpacing = 8.sp, fontWeight = FontWeight.Light)
                Text("Just A Rather Very Intelligent System", color = JarvisColors.CyanDim, fontSize = 11.sp)
                Text(
                    "ACCESSIBILITY ${if (ui.accessibilityEnabled) "ON" else "OFF"}  ·  AI BRAIN ${if (ui.backendUrl.isNotBlank()) "ON" else "OFF"}",
                    color = JarvisColors.CyanDim, fontSize = 10.sp, letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusPill("LISTENING", ui.state == JarvisState.LISTENING, Modifier.weight(1f))
                StatusPill("THINKING", ui.state == JarvisState.THINKING, Modifier.weight(1f))
                StatusPill("EXECUTING", ui.state == JarvisState.EXECUTING, Modifier.weight(1f))
                StatusPill("SPEAKING", ui.state == JarvisState.SPEAKING, Modifier.weight(1f))
            }
        }
        item { ArcReactor(ui.state, Modifier.fillMaxWidth(0.78f)) }
        item { VoiceWaveform(ui.state, level) }
        item {
            HoloPanel(Modifier.fillMaxWidth()) {
                Text("YOU", color = JarvisColors.CyanDim, fontSize = 10.sp, letterSpacing = 2.sp)
                Text(
                    ui.transcript.ifBlank { "…" },
                    color = JarvisColors.Text,
                    fontSize = 15.sp
                )
                Text("JARVIS", color = JarvisColors.CyanDim, fontSize = 10.sp, letterSpacing = 2.sp, modifier = Modifier.padding(top = 10.dp))
                Text(ui.response, color = JarvisColors.Cyan, fontSize = 15.sp)
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                MicButton(listening = ui.state == JarvisState.LISTENING, onClick = onMic)
                OutlinedButton(
                    onClick = onEmergencyStop,
                    border = BorderStroke(1.5.dp, JarvisColors.Red),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisColors.Red)
                ) { Text("EMERGENCY STOP", fontSize = 12.sp, letterSpacing = 1.sp) }
            }
        }
        item {
            Text(
                "COMMAND HISTORY",
                color = JarvisColors.CyanDim,
                fontSize = 11.sp,
                letterSpacing = 3.sp,
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (history.isEmpty()) {
            item { Text("No commands yet.", color = JarvisColors.CyanDim, fontSize = 13.sp) }
        } else {
            items(history, key = { it.id }) { h ->
                HoloPanel(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(h.spoken, color = JarvisColors.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text(
                            TimeUtils.clock(h.timestamp),
                            color = if (h.success) JarvisColors.CyanDim else JarvisColors.Amber,
                            fontSize = 11.sp
                        )
                    }
                    Text(h.response, color = JarvisColors.Cyan.copy(alpha = 0.8f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        item { androidx.compose.foundation.layout.Spacer(Modifier.height(8.dp)) }
    }
}
