package com.jarvis.ai

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.view.KeyEvent
import com.jarvis.ai.services.AccessibilityBridge
import kotlinx.coroutines.delay

/** Uses only official routes: a normal YouTube link, media keys, and user-enabled Accessibility. */
class YouTubeController(private val context: Context) {

    fun openSearch(query: String): Boolean {
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
        val inApp = Intent(Intent.ACTION_VIEW, uri).setPackage(YT_PACKAGE)
        if (start(inApp)) return true
        return start(Intent(Intent.ACTION_VIEW, uri)) // browser fallback
    }

    /** Waits for the results screen, then taps the first video. Returns false if it could not. */
    suspend fun openFirstResult(): Boolean {
        val service = AccessibilityBridge.service ?: return false
        repeat(12) {
            delay(700)
            if (service.clickFirstYouTubeResult()) return true
        }
        return false
    }

    /** action: play, pause, next, previous. Goes to whichever app is currently playing media. */
    fun mediaKey(action: String): Boolean {
        val code = when (action) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return false
        }
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return true
    }

    private fun start(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    }

    private companion object {
        const val YT_PACKAGE = "com.google.android.youtube"
    }
}
