package com.jarvis.ai.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [HistoryEntity::class, PrefEntity::class], version = 1, exportSchema = false)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao
    abstract fun prefDao(): PrefDao

    companion object {
        fun build(context: Context): JarvisDatabase =
            Room.databaseBuilder(context.applicationContext, JarvisDatabase::class.java, "jarvis.db").build()
    }
}
