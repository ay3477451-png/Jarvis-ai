package com.jarvis.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.jarvis.ai.models.JarvisLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Wraps Android's SpeechRecognizer. Must be used from the main thread. */
class VoiceRecognitionManager(private val context: Context) {

    interface Listener {
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onError(message: String)
    }

    private var recognizer: SpeechRecognizer? = null
    private var listener: Listener? = null

    private val _rms = MutableStateFlow(0f)
    /** Microphone level normalised to 0..1, drives the waveform animation. */
    val rms: StateFlow<Float> = _rms.asStateFlow()

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(language: JarvisLanguage, newListener: Listener) {
        destroyRecognizer()
        listener = newListener

        val r = SpeechRecognizer.createSpeechRecognizer(context)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onRmsChanged(rmsdB: Float) {
                _rms.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            }

            override fun onEndOfSpeech() {
                _rms.value = 0f
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) listener?.onPartial(text)
            }

            override fun onResults(results: Bundle?) {
                _rms.value = 0f
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                val l = listener
                listener = null
                if (text.isBlank()) l?.onError("I didn't catch that, sir. Tap and try again.")
                else l?.onFinal(text)
            }

            override fun onError(error: Int) {
                _rms.value = 0f
                val l = listener
                listener = null
                l?.onError(describe(error))
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.tag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        recognizer = r
        r.startListening(intent)
    }

    /** Stop capturing audio and deliver whatever was heard. */
    fun stop() {
        recognizer?.stopListening()
    }

    /** Abort immediately without delivering a result (emergency stop). */
    fun cancel() {
        listener = null
        recognizer?.cancel()
        _rms.value = 0f
    }

    fun destroy() {
        listener = null
        destroyRecognizer()
    }

    private fun destroyRecognizer() {
        recognizer?.destroy()
        recognizer = null
        _rms.value = 0f
    }

    private fun describe(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH,
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that, sir. Tap and try again."
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "The speech service needs an internet connection for this language."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer is busy. Please try again."
        SpeechRecognizer.ERROR_CLIENT -> "Listening stopped."
        else -> "Speech recognition error ($code)."
    }
}
