package com.jarvis.ai.utils

import com.jarvis.ai.models.JarvisCommand

/** Decides which actions must be confirmed by the user before JARVIS performs them. */
object SafetyPolicy {

    private val RISKY_WORDS = listOf(
        "send", "delete", "remove", "pay", "buy", "purchase", "order", "confirm",
        "uninstall", "transfer", "post", "submit", "reset", "erase",
        "भेज", "डिलीट", "हटा", "खरीद", "पेमेंट", "भुगतान", "ट्रांसफर", "सबमिट", "ऑर्डर", "पोस्ट"
    )

    fun isSensitive(cmd: JarvisCommand): Boolean = when (cmd) {
        is JarvisCommand.TypeText -> true // could be the body of a message
        is JarvisCommand.ClickText -> RISKY_WORDS.any { cmd.text.lowercase().contains(it) }
        else -> false
    }

    fun describe(cmd: JarvisCommand): String = when (cmd) {
        is JarvisCommand.TypeText -> "type \"${cmd.text}\" into the focused field"
        is JarvisCommand.ClickText -> "tap \"${cmd.text}\""
        else -> cmd.toString()
    }
}
