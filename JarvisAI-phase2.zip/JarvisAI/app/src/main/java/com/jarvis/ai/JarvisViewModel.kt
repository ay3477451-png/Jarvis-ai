package com.jarvis.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.database.HistoryEntity
import com.jarvis.ai.database.PrefEntity
import com.jarvis.ai.models.JarvisCommand
import com.jarvis.ai.models.JarvisLanguage
import com.jarvis.ai.models.JarvisState
import com.jarvis.ai.models.JarvisUiState
import com.jarvis.ai.models.PendingConfirm
import com.jarvis.ai.services.AccessibilityBridge
import com.jarvis.ai.services.JarvisAccessibilityService
import com.jarvis.ai.utils.SafetyPolicy
import com.jarvis.ai.utils.TimeUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private data class ExecResult(val message: String, val success: Boolean)

    private val repo = (app as JarvisApp).repository
    private val voice = VoiceRecognitionManager(app)
    private val tts = TextToSpeechManager(app)
    private val launcher = AppLauncher(app)
    private val youtube = YouTubeController(app)
    private val processor = CommandProcessor()
    private val ai = AIManager()

    private val _ui = MutableStateFlow(JarvisUiState())
    val ui: StateFlow<JarvisUiState> = _ui.asStateFlow()
    val rms: StateFlow<Float> = voice.rms
    val history: StateFlow<List<HistoryEntity>> =
        repo.history.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val memory: StateFlow<List<PrefEntity>> =
        repo.memory.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Asks MainActivity to move JARVIS to the background so actions hit the app the user was in. */
    private val _moveToBack = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val moveToBack: SharedFlow<Unit> = _moveToBack.asSharedFlow()

    @Volatile
    var appInForeground: Boolean = true

    private var job: Job? = null

    init {
        refreshAccessibility()
        viewModelScope.launch {
            val lang = repo.getPref(KEY_LANG)
                ?.let { saved -> JarvisLanguage.values().firstOrNull { it.name == saved } }
                ?: JarvisLanguage.ENGLISH
            _ui.update {
                it.copy(
                    language = lang,
                    pitch = repo.getPref(KEY_PITCH)?.toFloatOrNull() ?: 0.7f,
                    speechRate = repo.getPref(KEY_RATE)?.toFloatOrNull() ?: 0.9f,
                    ukVoice = repo.getPref(KEY_UK) == "true",
                    backendUrl = repo.getPref(KEY_URL).orEmpty(),
                    backendToken = repo.getPref(KEY_TOKEN).orEmpty()
                )
            }
            refreshVoiceName()
        }
    }

    fun refreshAccessibility() {
        val enabled = AccessibilityBridge.isEnabled(getApplication<Application>())
        _ui.update { it.copy(accessibilityEnabled = enabled) }
    }

    // ---------- user actions ----------

    fun onMicClick() {
        when (_ui.value.state) {
            JarvisState.LISTENING -> voice.stop()
            JarvisState.IDLE -> startListening()
            JarvisState.SPEAKING -> {
                tts.stop()
                startListening()
            }
            else -> Unit
        }
    }

    /** Emergency stop: cancels listening, speech, any running plan and any pending confirmation. */
    fun emergencyStop() {
        job?.cancel()
        voice.cancel()
        tts.stop()
        _ui.update {
            it.copy(
                state = JarvisState.IDLE,
                pendingConfirm = null,
                response = "Emergency stop engaged. All activity halted, sir."
            )
        }
    }

    fun confirmPending() {
        val p = _ui.value.pendingConfirm ?: return
        _ui.update { it.copy(pendingConfirm = null) }
        tts.stop()
        job?.cancel()
        job = viewModelScope.launch { runSteps(p.spoken, p.steps, p.reply, _ui.value.language) }
    }

    fun cancelPending() {
        if (_ui.value.pendingConfirm == null) return
        _ui.update { it.copy(pendingConfirm = null) }
        respond(tr(_ui.value.language, "Cancelled, sir.", "ठीक है सर, रद्द कर दिया।"))
    }

    fun setLanguage(language: JarvisLanguage) {
        _ui.update { it.copy(language = language) }
        viewModelScope.launch {
            repo.setPref(KEY_LANG, language.name)
            refreshVoiceName()
        }
    }

    fun setUkVoice(enabled: Boolean) {
        _ui.update { it.copy(ukVoice = enabled) }
        viewModelScope.launch {
            repo.setPref(KEY_UK, enabled.toString())
            refreshVoiceName()
        }
    }

    fun setPitch(value: Float) = _ui.update { it.copy(pitch = value) }
    fun setSpeechRate(value: Float) = _ui.update { it.copy(speechRate = value) }

    fun saveVoiceSettings() {
        val s = _ui.value
        viewModelScope.launch {
            repo.setPref(KEY_PITCH, s.pitch.toString())
            repo.setPref(KEY_RATE, s.speechRate.toString())
        }
    }

    /** Switch to the next installed voice for the current language and speak a sample. */
    fun cycleVoice() {
        val s = _ui.value
        val locale = ttsLocale(s)
        val names = tts.voiceNames(locale)
        if (names.isEmpty()) {
            respond(tr(s.language, "No other voices are installed for this language, sir.", "सर, इस भाषा की कोई दूसरी आवाज़ इंस्टॉल नहीं है।"))
            return
        }
        val next = names[(names.indexOf(s.voiceName) + 1) % names.size]
        _ui.update { it.copy(voiceName = next) }
        viewModelScope.launch { repo.setPref(voiceKey(locale), next) }
        respond(tr(s.language, "Good evening, sir. How does this voice sound?", "नमस्कार सर, यह आवाज़ कैसी लग रही है?"))
    }

    fun testVoice() {
        val lang = _ui.value.language
        respond(tr(lang, "Good evening, sir. All systems are operational.", "नमस्कार सर, सभी सिस्टम सक्रिय हैं।"))
    }

    /** Returns false if the URL is not https. A blank URL turns the AI brain off. */
    fun saveBackend(url: String, token: String): Boolean {
        val u = url.trim()
        val t = token.trim()
        if (u.isNotEmpty() && !u.startsWith("https://")) return false
        _ui.update { it.copy(backendUrl = u, backendToken = t) }
        viewModelScope.launch {
            repo.setPref(KEY_URL, u)
            repo.setPref(KEY_TOKEN, t)
        }
        return true
    }

    fun clearHistory() {
        viewModelScope.launch { repo.clearHistory() }
    }

    fun clearMemory() {
        viewModelScope.launch { repo.clearMemory() }
    }

    // ---------- pipeline: listen -> think -> (confirm) -> execute -> speak ----------

    private fun startListening() {
        if (!voice.isAvailable()) {
            _ui.update { it.copy(response = "No speech recognition service is available on this phone.") }
            return
        }
        tts.stop()
        _ui.update { it.copy(state = JarvisState.LISTENING, transcript = "") }
        voice.start(_ui.value.language, object : VoiceRecognitionManager.Listener {
            override fun onPartial(text: String) {
                _ui.update { it.copy(transcript = text) }
            }

            override fun onFinal(text: String) = handleSpoken(text)

            override fun onError(message: String) {
                _ui.update { it.copy(state = JarvisState.IDLE, response = message) }
            }
        })
    }

    private fun handleSpoken(text: String) {
        job?.cancel()
        job = viewModelScope.launch {
            _ui.update { it.copy(state = JarvisState.THINKING, transcript = text) }
            val lang = _ui.value.language
            val local = processor.parse(text)
            if (local is JarvisCommand.Unknown) {
                if (_ui.value.backendUrl.isBlank()) finishWith(text, unknownMessage(lang, text), false)
                else askAi(text, lang)
            } else {
                confirmOrRun(text, listOf(local), null, lang)
            }
        }
    }

    private suspend fun askAi(text: String, lang: JarvisLanguage) {
        val s = _ui.value
        val mem = repo.memoryNow().associate { it.key.removePrefix("mem:") to it.value }
        val result = ai.plan(s.backendUrl, s.backendToken, text, lang.tag, mem)
        val plan = result.getOrNull()
        if (plan == null) {
            val why = result.exceptionOrNull()?.message ?: "unknown error"
            finishWith(
                text,
                tr(lang, "My AI brain is unreachable, sir ($why).", "सर, मेरा AI ब्रेन अभी जुड़ नहीं पा रहा ($why)।"),
                false
            )
            return
        }
        plan.remember.forEach { (k, v) -> saveMemory(k, v) }
        val question = plan.clarify
        when {
            question != null -> finishWith(text, question, true)
            plan.steps.isEmpty() ->
                if (plan.reply.isNotBlank()) finishWith(text, plan.reply, true)
                else finishWith(text, unknownMessage(lang, text), false)
            else -> confirmOrRun(text, plan.steps, plan.reply, lang)
        }
    }

    private suspend fun saveMemory(key: String, value: String) {
        if (!Regex("[a-z0-9_]{1,40}").matches(key)) return
        if (value.length > 100 || Regex("\\d{8,}").containsMatchIn(value)) return // no long numbers
        val existing = repo.memoryNow()
        if (existing.size >= 30 && existing.none { it.key == "mem:$key" }) return
        repo.setPref("mem:$key", value)
    }

    private suspend fun confirmOrRun(text: String, steps: List<JarvisCommand>, reply: String?, lang: JarvisLanguage) {
        val risky = steps.filter { SafetyPolicy.isSensitive(it) }
        if (risky.isNotEmpty()) {
            val description = risky.joinToString("; ") { SafetyPolicy.describe(it) }
            _ui.update { it.copy(pendingConfirm = PendingConfirm(text, steps, reply, description)) }
            respond(tr(lang, "I need your confirmation, sir.", "सर, मुझे आपकी अनुमति चाहिए।"))
            return
        }
        runSteps(text, steps, reply, lang)
    }

    private suspend fun runSteps(text: String, steps: List<JarvisCommand>, reply: String?, lang: JarvisLanguage) {
        _ui.update { it.copy(state = JarvisState.EXECUTING) }
        val messages = mutableListOf<String>()
        var allOk = true
        var jarvisInFront = appInForeground

        for ((i, step) in steps.withIndex()) {
            // Screen actions must hit the app the user was in, not JARVIS itself.
            if (needsOtherApp(step) && jarvisInFront) {
                _moveToBack.tryEmit(Unit)
                delay(900)
                jarvisInFront = false
            }
            val r = executeStep(step, lang)
            messages += r.message
            if (!r.success) {
                allOk = false
                break
            }
            if (launchesApp(step)) jarvisInFront = false
            if (i < steps.lastIndex) delay(if (launchesApp(step)) 1800L else 700L)
        }

        val message = if (allOk && !reply.isNullOrBlank()) reply else messages.joinToString(" ")
        repo.addHistory(text, message, allOk)
        respond(message)
    }

    private fun needsOtherApp(c: JarvisCommand) =
        c is JarvisCommand.Scroll || c is JarvisCommand.GoBack || c is JarvisCommand.ReadScreen ||
            c is JarvisCommand.ClickText || c is JarvisCommand.TypeText

    private fun launchesApp(c: JarvisCommand) =
        c is JarvisCommand.OpenApp || c is JarvisCommand.OpenSettings ||
            c is JarvisCommand.PlayMusic || c is JarvisCommand.YouTubeSearch

    private suspend fun executeStep(cmd: JarvisCommand, lang: JarvisLanguage): ExecResult = when (cmd) {
        JarvisCommand.WakeOnly ->
            ExecResult(tr(lang, "Yes, sir? I'm listening.", "जी सर, मैं सुन रहा हूँ।"), true)

        JarvisCommand.TellTime -> ExecResult(TimeUtils.spokenTime(lang), true)

        JarvisCommand.Stop ->
            ExecResult(tr(lang, "Standing by, sir.", "ठीक है सर, मैं रुक गया।"), true)

        JarvisCommand.OpenSettings ->
            if (launcher.openSettings()) ExecResult(tr(lang, "Opening settings.", "सेटिंग्स खोल रहा हूँ।"), true)
            else ExecResult(tr(lang, "I couldn't open settings.", "मैं सेटिंग्स नहीं खोल पाया।"), false)

        is JarvisCommand.OpenApp -> {
            val label = launcher.openByName(cmd.name)
            if (label != null) ExecResult(tr(lang, "Opening $label.", "$label खोल रहा हूँ।"), true)
            else ExecResult(
                tr(lang, "I couldn't find ${cmd.display} on this phone, sir.", "सर, मुझे इस फोन पर ${cmd.display} नहीं मिला।"),
                false
            )
        }

        is JarvisCommand.PlayMusic ->
            if (launcher.playMusic(cmd.query)) {
                if (cmd.query.isBlank()) ExecResult(tr(lang, "Opening your music player.", "आपका म्यूज़िक प्लेयर खोल रहा हूँ।"), true)
                else ExecResult(tr(lang, "Searching for ${cmd.query}.", "${cmd.query} खोज रहा हूँ।"), true)
            } else ExecResult(tr(lang, "I couldn't find a music app, sir.", "सर, मुझे कोई म्यूज़िक ऐप नहीं मिला।"), false)

        is JarvisCommand.Scroll -> withService(lang) { s ->
            if (s.scroll(cmd.down)) ExecResult(
                if (cmd.down) tr(lang, "Scrolling down.", "नीचे स्क्रॉल कर रहा हूँ।")
                else tr(lang, "Scrolling up.", "ऊपर स्क्रॉल कर रहा हूँ।"),
                true
            ) else ExecResult(tr(lang, "I couldn't scroll here, sir.", "सर, यहाँ स्क्रॉल नहीं हो पाया।"), false)
        }

        JarvisCommand.GoBack -> withService(lang) { s ->
            if (s.back()) ExecResult(tr(lang, "Going back.", "पीछे जा रहा हूँ।"), true)
            else ExecResult(tr(lang, "I couldn't go back.", "मैं पीछे नहीं जा पाया।"), false)
        }

        JarvisCommand.GoHome -> withService(lang) { s ->
            if (s.home()) ExecResult(tr(lang, "Going to the home screen.", "होम स्क्रीन पर जा रहा हूँ।"), true)
            else ExecResult(tr(lang, "I couldn't go home.", "मैं होम स्क्रीन पर नहीं जा पाया।"), false)
        }

        JarvisCommand.ReadScreen -> withService(lang) { s ->
            val items = s.readScreen(15)
            if (items.isEmpty()) ExecResult(tr(lang, "I can't see readable text on this screen.", "इस स्क्रीन पर मुझे पढ़ने लायक कुछ नहीं दिखा।"), false)
            else ExecResult(items.joinToString(". ").take(400), true)
        }

        is JarvisCommand.ClickText -> withService(lang) { s ->
            if (s.clickByText(cmd.text)) ExecResult(tr(lang, "Tapped ${cmd.text}.", "${cmd.text} दबा दिया।"), true)
            else ExecResult(tr(lang, "I couldn't find \"${cmd.text}\" on screen, sir.", "सर, स्क्रीन पर \"${cmd.text}\" नहीं मिला।"), false)
        }

        is JarvisCommand.TypeText -> withService(lang) { s ->
            if (s.typeText(cmd.text)) ExecResult(tr(lang, "Typed it, sir.", "टाइप कर दिया सर।"), true)
            else ExecResult(
                tr(lang, "There's no text field ready to type into, sir.", "सर, टाइप करने के लिए कोई टेक्स्ट बॉक्स तैयार नहीं है।"),
                false
            )
        }

        is JarvisCommand.YouTubeSearch -> {
            val q = cmd.query
            if (!youtube.openSearch(q)) {
                ExecResult(tr(lang, "I couldn't open YouTube, sir.", "सर, मैं यूट्यूब नहीं खोल पाया।"), false)
            } else if (!cmd.playFirst) {
                ExecResult(tr(lang, "Searching YouTube for $q.", "यूट्यूब पर $q खोज रहा हूँ।"), true)
            } else if (!AccessibilityBridge.isEnabled(getApplication<Application>())) {
                ExecResult(
                    tr(lang, "Showing results for $q. Enable Accessibility to play the first one automatically.",
                        "$q के नतीजे दिखा रहा हूँ। पहला वीडियो अपने आप चलाने के लिए एक्सेसिबिलिटी चालू करें।"),
                    true
                )
            } else if (youtube.openFirstResult()) {
                ExecResult(tr(lang, "Playing $q.", "$q चला रहा हूँ।"), true)
            } else {
                ExecResult(
                    tr(lang, "Here are the results for $q, sir. I couldn't pick one automatically.",
                        "सर, $q के नतीजे ये रहे। मैं अपने आप कोई वीडियो नहीं चुन पाया।"),
                    true
                )
            }
        }

        is JarvisCommand.YouTubeControl ->
            if (youtube.mediaKey(cmd.action)) ExecResult(
                when (cmd.action) {
                    "pause" -> tr(lang, "Paused.", "रोक दिया।")
                    "play" -> tr(lang, "Playing.", "चला रहा हूँ।")
                    "next" -> tr(lang, "Next one.", "अगला।")
                    else -> tr(lang, "Previous one.", "पिछला।")
                },
                true
            ) else ExecResult(tr(lang, "I couldn't control playback.", "मैं प्लेबैक कंट्रोल नहीं कर पाया।"), false)

        is JarvisCommand.Unknown -> ExecResult(unknownMessage(lang, cmd.heard), false)
    }

    private fun withService(lang: JarvisLanguage, block: (JarvisAccessibilityService) -> ExecResult): ExecResult {
        val service = AccessibilityBridge.service
            ?: return ExecResult(
                tr(lang, "Please enable the Accessibility service in the Permissions tab, sir.",
                    "सर, कृपया Permissions टैब में एक्सेसिबिलिटी सर्विस चालू करें।"),
                false
            )
        return block(service)
    }

    private fun unknownMessage(lang: JarvisLanguage, heard: String) = tr(
        lang,
        "I didn't understand \"$heard\", sir. Try 'open YouTube', 'scroll down' or 'tell me the time'.",
        "सर, मैं \"$heard\" समझ नहीं पाया। कहें 'यूट्यूब खोलो', 'नीचे स्क्रॉल' या 'समय बताओ'।"
    )

    private suspend fun finishWith(text: String, message: String, success: Boolean) {
        repo.addHistory(text, message, success)
        respond(message)
    }

    private fun respond(message: String) {
        val s = _ui.value
        _ui.update { it.copy(state = JarvisState.SPEAKING, response = message) }
        val started = tts.speak(message, ttsLocale(s), s.voiceName.ifBlank { null }, s.pitch, s.speechRate) {
            _ui.update { cur -> if (cur.state == JarvisState.SPEAKING) cur.copy(state = JarvisState.IDLE) else cur }
        }
        if (!started) _ui.update { it.copy(state = JarvisState.IDLE) }
    }

    // ---------- helpers ----------

    private fun ttsLocale(s: JarvisUiState = _ui.value): Locale = when {
        s.language == JarvisLanguage.HINDI -> s.language.locale
        s.ukVoice -> Locale.UK
        else -> s.language.locale
    }

    private fun voiceKey(l: Locale) = "tts_voice_${l.toLanguageTag()}"

    private suspend fun refreshVoiceName() {
        val name = repo.getPref(voiceKey(ttsLocale())).orEmpty()
        _ui.update { it.copy(voiceName = name) }
    }

    private fun tr(lang: JarvisLanguage, en: String, hi: String) =
        if (lang == JarvisLanguage.HINDI) hi else en

    override fun onCleared() {
        voice.destroy()
        tts.shutdown()
        super.onCleared()
    }

    private companion object {
        const val KEY_LANG = "language"
        const val KEY_PITCH = "tts_pitch"
        const val KEY_RATE = "tts_rate"
        const val KEY_UK = "uk_voice"
        const val KEY_URL = "backend_url"
        const val KEY_TOKEN = "backend_token"
    }
}
