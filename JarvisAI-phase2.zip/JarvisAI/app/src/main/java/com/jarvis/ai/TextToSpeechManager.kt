package com.jarvis.ai

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale

/**
 * Text-to-speech tuned for a deep assistant voice: low pitch, slightly slow rate, and a voice the
 * user can cycle through in Settings (the phone's installed voices differ per device).
 */
class TextToSpeechManager(context: Context) {

    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var doneCallback: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            val engine = tts
            if (status == TextToSpeech.SUCCESS && engine != null) {
                engine.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = finish()

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finish()

                    override fun onError(utteranceId: String?, errorCode: Int) = finish()
                })
                ready = true
            }
        }
    }

    /** Names of installed offline voices for this language, same-country voices first. */
    fun voiceNames(locale: Locale): List<String> =
        usableVoices(locale).map { it.name }

    fun speak(
        text: String,
        locale: Locale,
        voiceName: String?,
        pitch: Float,
        rate: Float,
        onDone: () -> Unit
    ): Boolean {
        val engine = tts
        if (!ready || engine == null) return false

        doneCallback = onDone
        engine.setLanguage(locale)
        val chosen = usableVoices(locale).let { list ->
            list.firstOrNull { it.name == voiceName }
                ?: list.firstOrNull {
                    val n = it.name.lowercase()
                    n.contains("male") && !n.contains("female")
                }
        }
        if (chosen != null) engine.voice = chosen
        engine.setPitch(pitch)
        engine.setSpeechRate(rate)

        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.nanoTime()}")
        if (result == TextToSpeech.ERROR) {
            doneCallback = null
            return false
        }
        return true
    }

    fun stop() {
        doneCallback = null
        tts?.stop()
    }

    fun shutdown() {
        doneCallback = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }

    private fun finish() {
        val cb = doneCallback
        doneCallback = null
        cb?.invoke()
    }

    private fun usableVoices(locale: Locale): List<Voice> {
        val all = tts?.voices ?: return emptyList()
        return all
            .filter {
                it.locale.language == locale.language &&
                    !it.isNetworkConnectionRequired &&
                    it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true
            }
            .sortedWith(
                compareByDescending<Voice> { it.locale.country == locale.country }.thenBy { it.name }
            )
    }
}
