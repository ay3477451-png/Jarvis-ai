package com.jarvis.ai.utils

import com.jarvis.ai.models.JarvisLanguage
import java.text.SimpleDateFormat
import java.time.LocalTime
import java.util.Date
import java.util.Locale

object TimeUtils {
    fun spokenTime(lang: JarvisLanguage): String {
        val now = LocalTime.now()
        val h12 = if (now.hour % 12 == 0) 12 else now.hour % 12
        return if (lang == JarvisLanguage.HINDI) {
            val period = when (now.hour) {
                in 4..11 -> "सुबह"
                in 12..15 -> "दोपहर"
                in 16..19 -> "शाम"
                else -> "रात"
            }
            "सर, अभी $period के $h12 बजकर ${now.minute} मिनट हुए हैं।"
        } else {
            val ap = if (now.hour < 12) "AM" else "PM"
            "The time is $h12:${"%02d".format(now.minute)} $ap, sir."
        }
    }

    fun clock(millis: Long): String =
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(millis))
}
