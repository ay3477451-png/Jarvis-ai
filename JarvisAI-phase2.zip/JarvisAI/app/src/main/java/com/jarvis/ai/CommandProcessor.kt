package com.jarvis.ai

import com.jarvis.ai.models.JarvisCommand
import java.util.Locale

/**
 * Fast offline parser for common English / Hindi / Hinglish commands.
 * Anything it cannot understand becomes Unknown and is sent to the AI backend (if configured).
 */
class CommandProcessor {

    fun parse(raw: String): JarvisCommand {
        var text = normalize(raw)

        var hadWake = false
        WAKE_REGEX.find(text)?.let {
            hadWake = true
            text = text.substring(it.range.last + 1).trim()
        }
        if (text.isEmpty()) return if (hadWake) JarvisCommand.WakeOnly else JarvisCommand.Unknown(raw)

        if (text in STOP_WORDS) return JarvisCommand.Stop
        if (READ_WORDS.any { text.contains(it) }) return JarvisCommand.ReadScreen
        if (SCROLL_DOWN.any { text.contains(it) }) return JarvisCommand.Scroll(true)
        if (SCROLL_UP.any { text.contains(it) }) return JarvisCommand.Scroll(false)
        if (text == "back" || BACK_WORDS.any { text.contains(it) }) return JarvisCommand.GoBack
        if (HOME_WORDS.any { text.contains(it) }) return JarvisCommand.GoHome
        if (SETTINGS_WORDS.any { text.contains(it) }) return JarvisCommand.OpenSettings

        YT_CONTROL[text]?.let { return JarvisCommand.YouTubeControl(it) }

        val tokens = text.split(" ").filter { it.isNotBlank() }

        // "play despacito on youtube", "youtube par lofi search karo"
        if (YOUTUBE_ALIASES.any { text.contains(it) } && !text.contains("music") &&
            tokens.any { it in SEARCH_WORDS || it in PLAY_WORDS }
        ) {
            val query = tokens.filterNot { it in YT_NOISE }.joinToString(" ")
            return if (query.isBlank()) JarvisCommand.OpenApp("youtube", "YouTube")
            else JarvisCommand.YouTubeSearch(query, playFirst = tokens.any { it in PLAY_WORDS })
        }

        if (tokens.any { it in OPEN_WORDS }) {
            val name = tokens.filterNot { it in OPEN_WORDS || it in OPEN_NOISE }.joinToString(" ")
            if (name.isBlank()) return JarvisCommand.Unknown(raw)
            return when {
                YOUTUBE_ALIASES.any { name.contains(it) } && !name.contains("music") ->
                    JarvisCommand.OpenApp("youtube", "YouTube")
                WHATSAPP_ALIASES.any { name.contains(it) } ->
                    JarvisCommand.OpenApp("whatsapp", "WhatsApp")
                else -> JarvisCommand.OpenApp(name, name)
            }
        }

        // "click Search", "tap Subscribe", "सब्सक्राइब पर क्लिक करो"
        if (tokens.first() in CLICK_PREFIX && tokens.size > 1) {
            return JarvisCommand.ClickText(tokens.drop(1).joinToString(" "))
        }
        if (tokens.any { it in CLICK_HI }) {
            val target = tokens.filterNot { it in CLICK_HI || it in CLICK_NOISE }.joinToString(" ")
            if (target.isNotBlank()) return JarvisCommand.ClickText(target)
        }

        // "type hello", "likho hello"
        if (tokens.first() in TYPE_PREFIX && tokens.size > 1) {
            return JarvisCommand.TypeText(tokens.drop(1).joinToString(" "))
        }

        val isMusic = text.startsWith("play ") || MUSIC_WORDS.any { text.contains(it) }
        if (isMusic) {
            val query = tokens.filterNot { it in MUSIC_NOISE }.joinToString(" ")
            return JarvisCommand.PlayMusic(query)
        }

        if (TIME_WORDS.any { text.contains(it) }) return JarvisCommand.TellTime

        return JarvisCommand.Unknown(raw)
    }

    private fun normalize(raw: String): String =
        raw.lowercase(Locale.ROOT)
            .replace(Regex("[.,!?।]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private companion object {
        val WAKE_REGEX = Regex(
            "^(?:hey|hi|hello|ok|okay|हे|हेलो|हैलो)?\\s*(?:jarvis|जार्विस|जारविस|जर्विस|जार्वीस)\\s*"
        )

        val STOP_WORDS = setOf("stop", "cancel", "ruko", "रुको", "रुक जाओ", "चुप", "chup")

        val READ_WORDS = listOf("read screen", "read the screen", "screen padho", "screen read", "स्क्रीन पढ")
        val SCROLL_DOWN = listOf("scroll down", "स्क्रॉल डाउन", "नीचे स्क्रॉल", "neeche scroll", "scroll neeche", "नीचे जाओ", "neeche jao")
        val SCROLL_UP = listOf("scroll up", "स्क्रॉल अप", "ऊपर स्क्रॉल", "upar scroll", "scroll upar", "ऊपर जाओ", "upar jao")
        val BACK_WORDS = listOf("go back", "पीछे जाओ", "वापस जाओ", "peeche jao", "back jao")
        val HOME_WORDS = listOf("go home", "go to home", "home screen", "होम स्क्रीन", "होम पर जाओ", "home jao")

        val SETTINGS_WORDS = listOf("settings", "सेटिंग", "setting kholo")

        val YT_CONTROL = mapOf(
            "pause" to "pause", "pause karo" to "pause", "पॉज" to "pause", "पॉज़" to "pause", "रोको" to "pause",
            "play" to "play", "resume" to "play", "चलाओ" to "play",
            "next" to "next", "next song" to "next", "next video" to "next", "अगला" to "next", "agla" to "next",
            "previous" to "previous", "previous song" to "previous", "पिछला" to "previous", "pichla" to "previous"
        )

        val SEARCH_WORDS = setOf("search", "find", "खोजो", "खोज", "सर्च")
        val PLAY_WORDS = setOf("play", "chalao", "bajao", "चलाओ", "बजाओ", "चला", "लगाओ", "lagao")
        val YT_NOISE = setOf(
            "play", "search", "find", "open", "launch", "youtube", "you", "tube", "यूट्यूब", "यूटयूब", "यू", "ट्यूब",
            "on", "in", "for", "the", "a", "and", "to", "par", "pe", "पर", "पे", "में", "से", "se",
            "song", "songs", "video", "videos", "गाना", "गाने", "वीडियो", "video",
            "khojo", "खोजो", "खोज", "सर्च", "chalao", "bajao", "चलाओ", "बजाओ", "चला", "लगाओ", "lagao",
            "kholo", "खोलो", "karo", "करो", "kar", "कर", "please"
        )

        val OPEN_WORDS = setOf("open", "launch", "kholo", "kholiye", "khol", "खोलो", "खोलिए", "खोलिये", "खोल")
        val OPEN_NOISE = setOf("please", "plz", "the", "app", "ऐप", "एप", "karo", "करो", "जी")

        val YOUTUBE_ALIASES = listOf("youtube", "you tube", "यूट्यूब", "यूटयूब", "यू ट्यूब")
        val WHATSAPP_ALIASES = listOf("whatsapp", "whats app", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सएप", "वाट्सएप", "व्हाट्स ऐप")

        val CLICK_PREFIX = setOf("click", "tap", "press")
        val CLICK_HI = setOf("क्लिक", "दबाओ", "dabao")
        val CLICK_NOISE = setOf("करो", "karo", "पर", "par", "को", "ko", "please")
        val TYPE_PREFIX = setOf("type", "likho", "लिखो")

        val MUSIC_WORDS = listOf("music", "song", "गाना", "गाने", "संगीत", "gana", "gaana")
        val MUSIC_NOISE = setOf(
            "play", "music", "song", "songs", "the", "some", "me", "a", "for", "please",
            "गाना", "गाने", "संगीत", "बजाओ", "चलाओ", "सुनाओ", "bajao", "chalao", "sunao", "gana", "gaana"
        )

        val TIME_WORDS = listOf("time", "samay", "समय", "टाइम", "baje", "बजे")
    }
}
