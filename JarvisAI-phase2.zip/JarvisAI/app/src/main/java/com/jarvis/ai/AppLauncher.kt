package com.jarvis.ai

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings

/** Launches apps through normal public Android intents only. */
class AppLauncher(private val context: Context) {

    private val knownPackages = mapOf(
        "youtube" to "com.google.android.youtube",
        "whatsapp" to "com.whatsapp"
    )

    /** Opens an app by canonical name or by installed label. Returns the opened label, or null. */
    fun openByName(name: String): String? {
        val key = name.trim().lowercase()
        if (key.isEmpty()) return null

        knownPackages[key]?.let { pkg ->
            if (launchPackage(pkg)) return key.replaceFirstChar { it.uppercase() }
        }

        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcherIntent, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(key)
        } ?: return null

        val pkg = match.activityInfo.packageName
        return if (launchPackage(pkg)) match.loadLabel(pm).toString() else null
    }

    fun openSettings(): Boolean = startSafely(Intent(Settings.ACTION_SETTINGS))

    /**
     * Phase 1: simple, officially supported intents.
     * Blank query opens the default music app; otherwise a media "play from search" request,
     * falling back to a YouTube search page. Rich YouTube control arrives in Phase 2.
     */
    fun playMusic(query: String): Boolean {
        if (query.isBlank()) {
            val music = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
            return startSafely(music) || openByName("youtube") != null
        }
        val search = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
        }
        if (startSafely(search)) return true
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)))
        return startSafely(web)
    }

    private fun launchPackage(pkg: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return startSafely(intent)
    }

    private fun startSafely(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }
}
