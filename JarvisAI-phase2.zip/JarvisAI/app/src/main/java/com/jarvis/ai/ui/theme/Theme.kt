package com.jarvis.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object JarvisColors {
    val Bg = Color(0xFF02060F)
    val DeepBlue = Color(0xFF06183A)
    val Panel = Color(0xFF07142B)
    val Cyan = Color(0xFF00E5FF)
    val CyanDim = Color(0xFF3A8FA0)
    val Amber = Color(0xFFFFB300)
    val Red = Color(0xFFFF3D4D)
    val Text = Color(0xFFCFF8FF)
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = JarvisColors.Cyan,
            onPrimary = JarvisColors.Bg,
            secondary = JarvisColors.CyanDim,
            background = JarvisColors.Bg,
            surface = JarvisColors.Panel,
            onBackground = JarvisColors.Text,
            onSurface = JarvisColors.Text,
            error = JarvisColors.Red
        ),
        typography = Typography(),
        content = content
    )
}
