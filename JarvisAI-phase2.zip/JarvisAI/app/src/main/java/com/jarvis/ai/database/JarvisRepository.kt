package com.jarvis.ai.database

import kotlinx.coroutines.flow.Flow

class JarvisRepository(
    private val historyDao: HistoryDao,
    private val prefDao: PrefDao
) {
    val history: Flow<List<HistoryEntity>> = historyDao.observe()
    val memory: Flow<List<PrefEntity>> = prefDao.observeMemory()

    suspend fun addHistory(spoken: String, response: String, success: Boolean) =
        historyDao.insert(HistoryEntity(spoken = spoken, response = response, success = success, timestamp = System.currentTimeMillis()))

    suspend fun clearHistory() = historyDao.clear()

    suspend fun getPref(key: String): String? = prefDao.get(key)

    suspend fun setPref(key: String, value: String) = prefDao.put(PrefEntity(key, value))

    suspend fun memoryNow(): List<PrefEntity> = prefDao.memoryNow()

    suspend fun clearMemory() = prefDao.clearMemory()
}
