package com.jarvis.ai.models

/**
 * Fixed whitelist of things JARVIS can do. Both the local parser and the AI backend can only
 * produce these types, so no AI-generated code is ever executed.
 */
sealed interface JarvisCommand {
    data object WakeOnly : JarvisCommand
    data object TellTime : JarvisCommand
    data object OpenSettings : JarvisCommand
    data object Stop : JarvisCommand
    data object GoBack : JarvisCommand
    data object GoHome : JarvisCommand
    data object ReadScreen : JarvisCommand
    data class OpenApp(val name: String, val display: String) : JarvisCommand
    data class PlayMusic(val query: String) : JarvisCommand
    data class Scroll(val down: Boolean) : JarvisCommand
    data class ClickText(val text: String) : JarvisCommand
    data class TypeText(val text: String) : JarvisCommand
    data class YouTubeSearch(val query: String, val playFirst: Boolean) : JarvisCommand
    /** action: play, pause, next or previous */
    data class YouTubeControl(val action: String) : JarvisCommand
    data class Unknown(val heard: String) : JarvisCommand
}
