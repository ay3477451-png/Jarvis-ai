package com.jarvis.ai

import android.app.Application
import com.jarvis.ai.database.JarvisDatabase
import com.jarvis.ai.database.JarvisRepository

class JarvisApp : Application() {
    val database by lazy { JarvisDatabase.build(this) }
    val repository by lazy { JarvisRepository(database.historyDao(), database.prefDao()) }
}
