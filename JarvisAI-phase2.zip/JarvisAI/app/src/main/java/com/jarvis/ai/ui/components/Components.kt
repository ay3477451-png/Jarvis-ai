package com.jarvis.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.models.JarvisState
import com.jarvis.ai.ui.theme.JarvisColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Animated arc-reactor. Spin speed and colour change with the assistant state. */
@Composable
fun ArcReactor(state: JarvisState, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "reactor")
    val spinMs = when (state) {
        JarvisState.IDLE -> 14000
        JarvisState.LISTENING -> 6000
        JarvisState.THINKING -> 1800
        JarvisState.EXECUTING -> 2500
        JarvisState.SPEAKING -> 4500
    }
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(spinMs, easing = LinearEasing)),
        label = "spin"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val color = if (state == JarvisState.THINKING) JarvisColors.Amber else JarvisColors.Cyan

    Canvas(modifier = modifier.aspectRatio(1f)) {
        val c = center
        val r = size.minDimension / 2f

        drawCircle(
            brush = Brush.radialGradient(listOf(color.copy(alpha = 0.30f), Color.Transparent), center = c, radius = r),
            radius = r
        )
        drawCircle(color.copy(alpha = 0.5f), radius = r * 0.96f, style = Stroke(2.dp.toPx()))

        rotate(spin * 0.3f, c) {
            for (i in 0 until 60) {
                val a = Math.toRadians(i * 6.0)
                val len = if (i % 5 == 0) r * 0.07f else r * 0.035f
                val outer = r * 0.93f
                drawLine(
                    color = color.copy(alpha = 0.6f),
                    start = Offset(c.x + cos(a).toFloat() * outer, c.y + sin(a).toFloat() * outer),
                    end = Offset(c.x + cos(a).toFloat() * (outer - len), c.y + sin(a).toFloat() * (outer - len)),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
        }

        rotate(spin, c) {
            for (i in 0 until 3) {
                drawArc(
                    color = color,
                    startAngle = i * 120f,
                    sweepAngle = 70f,
                    useCenter = false,
                    topLeft = Offset(c.x - r * 0.78f, c.y - r * 0.78f),
                    size = Size(r * 1.56f, r * 1.56f),
                    style = Stroke(6.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        rotate(-spin * 1.5f, c) {
            for (i in 0 until 4) {
                drawArc(
                    color = color.copy(alpha = 0.8f),
                    startAngle = i * 90f,
                    sweepAngle = 40f,
                    useCenter = false,
                    topLeft = Offset(c.x - r * 0.6f, c.y - r * 0.6f),
                    size = Size(r * 1.2f, r * 1.2f),
                    style = Stroke(4.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        drawCircle(color.copy(alpha = 0.7f), radius = r * 0.42f, style = Stroke(3.dp.toPx()))

        val coreR = r * 0.4f * pulse
        drawCircle(
            brush = Brush.radialGradient(listOf(Color.White, color, color.copy(alpha = 0f)), center = c, radius = coreR),
            radius = coreR
        )
    }
}

/** Bar waveform. LISTENING follows the real microphone level; other states use a gentle idle wave. */
@Composable
fun VoiceWaveform(state: JarvisState, level: Float, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "phase"
    )
    val target = when (state) {
        JarvisState.LISTENING -> 0.15f + level * 0.85f
        JarvisState.SPEAKING -> 0.6f
        JarvisState.THINKING, JarvisState.EXECUTING -> 0.25f
        JarvisState.IDLE -> 0.06f
    }
    val amp by animateFloatAsState(target, tween(120), label = "amp")

    Canvas(modifier = modifier.fillMaxWidth().height(56.dp)) {
        val bars = 40
        val gap = size.width / bars
        val barW = gap * 0.5f
        for (i in 0 until bars) {
            val envelope = sin(PI * i / (bars - 1)).toFloat()
            val wave = (sin(phase + i * 0.45f) + 1f) / 2f
            val h = (size.height * (0.08f + amp * envelope * (0.35f + 0.65f * wave))).coerceAtMost(size.height)
            val x = gap * i + gap / 2f
            drawLine(
                color = JarvisColors.Cyan,
                start = Offset(x, size.height / 2f - h / 2f),
                end = Offset(x, size.height / 2f + h / 2f),
                strokeWidth = barW,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun StatusPill(label: String, active: Boolean, modifier: Modifier = Modifier) {
    val c = if (active) JarvisColors.Cyan else JarvisColors.CyanDim
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .border(1.dp, c.copy(alpha = if (active) 1f else 0.4f), RoundedCornerShape(50))
            .background(if (active) c.copy(alpha = 0.18f) else Color.Transparent)
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(c))
        Spacer(Modifier.width(4.dp))
        Text(label, color = c, fontSize = 9.sp, letterSpacing = 0.5.sp, maxLines = 1)
    }
}

@Composable
fun MicButton(listening: Boolean, onClick: () -> Unit) {
    val color = JarvisColors.Cyan
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(JarvisColors.Panel)
            .border(2.dp, color, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(28.dp)) {
            val w = size.width
            val h = size.height
            if (listening) {
                drawRoundRect(color, Offset(w * 0.2f, h * 0.2f), Size(w * 0.6f, h * 0.6f), CornerRadius(4.dp.toPx()))
            } else {
                drawRoundRect(color, Offset(w * 0.35f, h * 0.05f), Size(w * 0.3f, h * 0.5f), CornerRadius(w * 0.15f))
                drawArc(color, 0f, 180f, false, Offset(w * 0.2f, h * 0.25f), Size(w * 0.6f, h * 0.5f), style = Stroke(2.dp.toPx()))
                drawLine(color, Offset(w * 0.5f, h * 0.75f), Offset(w * 0.5f, h * 0.95f), 2.dp.toPx())
                drawLine(color, Offset(w * 0.35f, h * 0.95f), Offset(w * 0.65f, h * 0.95f), 2.dp.toPx())
            }
        }
    }
}

/** Dark panel with a thin glowing cyan border. */
@Composable
fun HoloPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(JarvisColors.Panel.copy(alpha = 0.75f))
            .border(1.dp, JarvisColors.Cyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(12.dp),
        content = content
    )
}
