package com.jarvis.ai.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY timestamp DESC LIMIT 50")
    fun observe(): Flow<List<HistoryEntity>>

    @Insert
    suspend fun insert(item: HistoryEntity)

    @Query("DELETE FROM history")
    suspend fun clear()
}

@Dao
interface PrefDao {
    @Query("SELECT value FROM prefs WHERE `key` = :key LIMIT 1")
    suspend fun get(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(pref: PrefEntity)

    /** Remembered user preferences are stored with keys starting "mem:". */
    @Query("SELECT * FROM prefs WHERE `key` LIKE 'mem:%' ORDER BY `key`")
    fun observeMemory(): Flow<List<PrefEntity>>

    @Query("SELECT * FROM prefs WHERE `key` LIKE 'mem:%'")
    suspend fun memoryNow(): List<PrefEntity>

    @Query("DELETE FROM prefs WHERE `key` LIKE 'mem:%'")
    suspend fun clearMemory()
}
