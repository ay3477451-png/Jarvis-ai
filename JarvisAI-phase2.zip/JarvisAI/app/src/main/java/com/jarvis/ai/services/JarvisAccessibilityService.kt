package com.jarvis.ai.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Works only after the user enables it in Android settings. It does nothing by itself:
 * every method below runs only when the user asks JARVIS for that action.
 * Password fields are never read or filled.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        AccessibilityBridge.service = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        AccessibilityBridge.service = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        AccessibilityBridge.service = null
        super.onDestroy()
    }

    // ---------- navigation ----------

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    // ---------- gestures ----------

    fun tap(x: Float, y: Float): Boolean =
        dispatch(Path().apply { moveTo(x, y) }, 50)

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 300): Boolean =
        dispatch(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, durationMs)

    private fun dispatch(path: Path, durationMs: Long): Boolean {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    /** Scrolls the largest scrollable area on screen; falls back to a swipe gesture. */
    fun scroll(down: Boolean): Boolean {
        val root = rootInActiveWindow
        if (root != null) {
            val scrollables = mutableListOf<AccessibilityNodeInfo>()
            collect(root, scrollables) { it.isScrollable }
            val target = scrollables.maxByOrNull { n ->
                val r = Rect()
                n.getBoundsInScreen(r)
                r.width().toLong() * r.height().toLong()
            }
            if (target != null) {
                val action = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (target.performAction(action)) return true
            }
        }
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        return if (down) swipe(x, m.heightPixels * 0.7f, x, m.heightPixels * 0.3f, 350)
        else swipe(x, m.heightPixels * 0.3f, x, m.heightPixels * 0.7f, 350)
    }

    // ---------- reading the screen ----------

    fun readScreen(maxItems: Int = 20): List<String> {
        val out = LinkedHashSet<String>()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || out.size >= maxItems || depth > 30) return
            if (!node.isPassword && node.isVisibleToUser) {
                val t = (node.text ?: node.contentDescription)?.toString()?.trim()
                if (!t.isNullOrEmpty() && t.length < 200) out.add(t)
            }
            for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1)
        }
        walk(rootInActiveWindow, 0)
        return out.toList()
    }

    // ---------- clicking and typing ----------

    fun clickByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (node in root.findAccessibilityNodeInfosByText(text)) {
            if (node.isPassword) continue
            if (clickNodeOrParent(node)) return true
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (node.isPassword || !node.isEditable) return false
        val existing = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, existing + text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Taps the first video in the YouTube app's search results (looks for "play video" labels). */
    fun clickFirstYouTubeResult(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != "com.google.android.youtube") return false
        val matches = mutableListOf<AccessibilityNodeInfo>()
        collect(root, matches) {
            it.contentDescription?.toString()?.contains("play video", ignoreCase = true) == true
        }
        val first = matches.firstOrNull() ?: return false
        return clickNodeOrParent(first)
    }

    // ---------- helpers ----------

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        var depth = 0
        while (cur != null && depth < 6) {
            if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        return !r.isEmpty && tap(r.exactCenterX(), r.exactCenterY())
    }

    private fun collect(
        node: AccessibilityNodeInfo?,
        out: MutableList<AccessibilityNodeInfo>,
        depth: Int = 0,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ) {
        if (node == null || depth > 40) return
        if (predicate(node)) out.add(node)
        for (i in 0 until node.childCount) collect(node.getChild(i), out, depth + 1, predicate)
    }
}
