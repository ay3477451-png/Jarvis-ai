package com.jarvis.ai.models

enum class JarvisState { IDLE, LISTENING, THINKING, EXECUTING, SPEAKING }
