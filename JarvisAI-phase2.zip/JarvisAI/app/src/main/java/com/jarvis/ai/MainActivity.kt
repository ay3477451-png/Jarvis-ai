package com.jarvis.ai

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import com.jarvis.ai.ui.screens.JarvisRoot
import com.jarvis.ai.ui.theme.JarvisTheme
import com.jarvis.ai.utils.PermissionUtils
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()
    private var micGranted by mutableStateOf(false)

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            micGranted = granted
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        micGranted = PermissionUtils.hasMicrophone(this)

        // When a screen action must hit another app, JARVIS steps aside first.
        lifecycleScope.launch {
            viewModel.moveToBack.collect { moveTaskToBack(true) }
        }

        setContent {
            JarvisTheme {
                JarvisRoot(
                    vm = viewModel,
                    micGranted = micGranted,
                    onRequestMic = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                    onOpenAppSettings = {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                        )
                    },
                    onOpenAccessibilitySettings = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.appInForeground = true
    }

    override fun onStop() {
        viewModel.appInForeground = false
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        micGranted = PermissionUtils.hasMicrophone(this)
        viewModel.refreshAccessibility()
    }
}
