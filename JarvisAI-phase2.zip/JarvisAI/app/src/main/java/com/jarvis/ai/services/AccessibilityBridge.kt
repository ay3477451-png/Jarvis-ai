package com.jarvis.ai.services

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

/** Lets the rest of the app reach the AccessibilityService, which only the user can enable. */
object AccessibilityBridge {

    @Volatile
    var service: JarvisAccessibilityService? = null

    fun isEnabled(context: Context): Boolean {
        if (service != null) return true
        val resolver = context.contentResolver
        if (Settings.Secure.getInt(resolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 1) return false
        val list = Settings.Secure.getString(resolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val component = ComponentName(context, JarvisAccessibilityService::class.java)
        return list.split(':').any {
            it.equals(component.flattenToString(), true) || it.equals(component.flattenToShortString(), true)
        }
    }
}
