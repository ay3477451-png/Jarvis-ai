package com.jarvis.ai.models

import java.util.Locale

enum class JarvisLanguage(val tag: String, val label: String) {
    ENGLISH("en-IN", "English"),
    HINDI("hi-IN", "हिन्दी");

    val locale: Locale get() = Locale.forLanguageTag(tag)
}
