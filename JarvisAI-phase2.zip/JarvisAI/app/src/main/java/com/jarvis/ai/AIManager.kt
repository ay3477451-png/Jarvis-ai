package com.jarvis.ai

import com.jarvis.ai.models.JarvisCommand
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Talks to YOUR backend (see backend/cloudflare-worker.js), never to Gemini directly, so the
 * Gemini API key stays on the server. The backend returns a JSON plan; this class converts it into
 * the fixed JarvisCommand whitelist. Unknown actions are dropped, nothing is ever executed as code.
 */
class AIManager {

    data class AiPlan(
        val reply: String,
        val clarify: String?,
        val steps: List<JarvisCommand>,
        val remember: Map<String, String>
    )

    suspend fun plan(
        baseUrl: String,
        token: String,
        text: String,
        languageTag: String,
        memory: Map<String, String>
    ): Result<AiPlan> = withContext(Dispatchers.IO) {
        runCatching {
            require(baseUrl.startsWith("https://")) { "Backend URL must start with https://" }

            val body = JSONObject()
                .put("text", text)
                .put("language", languageTag)
                .put("memory", JSONObject(memory))
                .toString()

            val conn = (URL(baseUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 30_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer $token")
            }
            try {
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) error("backend returned $code")
                parse(response)
            } finally {
                conn.disconnect()
            }
        }
    }

    private fun parse(json: String): AiPlan {
        val o = JSONObject(json)
        val steps = mutableListOf<JarvisCommand>()
        val arr = o.optJSONArray("steps")
        if (arr != null) {
            for (i in 0 until minOf(arr.length(), 8)) {
                toCommand(arr.optJSONObject(i))?.let { steps.add(it) }
            }
        }
        val remember = mutableMapOf<String, String>()
        o.optJSONObject("remember")?.let { r ->
            r.keys().forEach { k -> r.optString(k).takeIf { v -> v.isNotBlank() }?.let { v -> remember[k] = v } }
        }
        val clarify = o.optString("clarify", "").trim().takeIf { it.isNotEmpty() && it != "null" }
        return AiPlan(o.optString("reply", "").trim(), clarify, steps, remember)
    }

    private fun toCommand(s: JSONObject?): JarvisCommand? {
        if (s == null) return null
        return when (s.optString("action")) {
            "open_app" -> {
                val name = s.optString("name").trim().lowercase()
                if (name.isEmpty()) null
                else JarvisCommand.OpenApp(name, name.replaceFirstChar { it.uppercase() })
            }
            "open_settings" -> JarvisCommand.OpenSettings
            "play_music" -> JarvisCommand.PlayMusic(s.optString("query").trim())
            "youtube_search" -> {
                val q = s.optString("query").trim()
                if (q.isEmpty()) null else JarvisCommand.YouTubeSearch(q, s.optBoolean("play_first", false))
            }
            "youtube_control" -> {
                val a = s.optString("action_type", s.optString("control")).trim().lowercase()
                if (a in setOf("play", "pause", "next", "previous")) JarvisCommand.YouTubeControl(a) else null
            }
            "scroll_down" -> JarvisCommand.Scroll(true)
            "scroll_up" -> JarvisCommand.Scroll(false)
            "go_back" -> JarvisCommand.GoBack
            "go_home" -> JarvisCommand.GoHome
            "read_screen" -> JarvisCommand.ReadScreen
            "click_text" -> s.optString("text").trim().takeIf { it.isNotEmpty() }?.let { JarvisCommand.ClickText(it) }
            "type_text" -> s.optString("text").takeIf { it.isNotEmpty() }?.let { JarvisCommand.TypeText(it) }
            "tell_time" -> JarvisCommand.TellTime
            else -> null
        }
    }
}
