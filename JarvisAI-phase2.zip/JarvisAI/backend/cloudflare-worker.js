// JARVIS AI backend for Cloudflare Workers (free plan is enough).
// Secrets to set in Cloudflare (Settings > Variables and Secrets):
//   GEMINI_API_KEY  - your key from aistudio.google.com/app/apikey
//   APP_TOKEN       - any long random password; type the same one in the app's Settings
// Optional variable:
//   GEMINI_MODEL    - defaults to "gemini-flash-latest"; change it if Google renames models.

const SYSTEM = `You are the planner for JARVIS, an Android voice assistant.
Convert the user's request (English, Hindi or Hinglish) into ONE JSON object and output ONLY that JSON:
{"reply": string, "clarify": string|null, "steps": [ {"action": ...}, ... ], "remember": { "key": "value" }}

Allowed actions (use nothing else, never invent actions):
- {"action":"open_app","name":"youtube"}   (app name as a person would say it)
- {"action":"open_settings"}
- {"action":"play_music","query":"..."}
- {"action":"youtube_search","query":"...","play_first":true|false}
- {"action":"youtube_control","control":"play"|"pause"|"next"|"previous"}
- {"action":"scroll_down"} {"action":"scroll_up"} {"action":"go_back"} {"action":"go_home"}
- {"action":"read_screen"}
- {"action":"click_text","text":"visible label to tap"}
- {"action":"type_text","text":"text to type into the focused field"}
- {"action":"tell_time"}

Rules:
- Maximum 8 steps, in the order they must happen.
- "reply" is a short spoken confirmation. Use Hindi (Devanagari) if language starts with "hi", otherwise English. Address the user as sir / सर.
- If the request is ambiguous or not possible with the actions above, set "clarify" to ONE short question (same language) and use an empty steps list.
- Do not tap send, delete, pay, buy or order buttons unless the user clearly asked for exactly that. The app will ask the user to confirm anyway.
- Never include passwords, OTPs, card numbers or other sensitive data anywhere.
- "memory" in the input holds things already remembered about the user; use it when relevant (for example a favourite music app).
- Put into "remember" only stable, harmless preferences the user states about themselves (snake_case key up to 40 chars, value up to 100 chars, e.g. favorite_music_app). Otherwise use an empty object.`;

const ALLOWED = new Set([
  "open_app", "open_settings", "play_music", "youtube_search", "youtube_control",
  "scroll_down", "scroll_up", "go_back", "go_home", "read_screen",
  "click_text", "type_text", "tell_time",
]);

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" },
  });
}

function sanitize(plan) {
  const steps = Array.isArray(plan.steps)
    ? plan.steps.filter((s) => s && typeof s === "object" && ALLOWED.has(s.action)).slice(0, 8)
    : [];
  const remember = {};
  if (plan.remember && typeof plan.remember === "object") {
    for (const [k, v] of Object.entries(plan.remember).slice(0, 5)) {
      if (/^[a-z0-9_]{1,40}$/.test(k) && typeof v === "string" && v.length <= 100) remember[k] = v;
    }
  }
  return {
    reply: typeof plan.reply === "string" ? plan.reply.slice(0, 300) : "",
    clarify: typeof plan.clarify === "string" && plan.clarify ? plan.clarify.slice(0, 200) : null,
    steps,
    remember,
  };
}

export default {
  async fetch(request, env) {
    if (request.method !== "POST") return new Response("JARVIS backend online", { status: 200 });

    const auth = request.headers.get("Authorization") || "";
    if (!env.APP_TOKEN || auth !== `Bearer ${env.APP_TOKEN}`) return json({ error: "unauthorized" }, 401);
    if (!env.GEMINI_API_KEY) return json({ error: "GEMINI_API_KEY not set" }, 500);

    let body;
    try {
      body = await request.json();
    } catch {
      return json({ error: "bad json" }, 400);
    }

    const text = String(body.text || "").slice(0, 500);
    const language = String(body.language || "en-IN").slice(0, 10);
    const memory = body.memory && typeof body.memory === "object" ? body.memory : {};
    const model = env.GEMINI_MODEL || "gemini-flash-latest";

    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM }] },
          contents: [{ role: "user", parts: [{ text: JSON.stringify({ user_said: text, language, memory }) }] }],
          generationConfig: { temperature: 0.2, responseMimeType: "application/json" },
        }),
      }
    );
    if (!res.ok) return json({ error: `gemini ${res.status}` }, 502);

    const data = await res.json();
    const raw = data?.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
    let plan;
    try {
      plan = JSON.parse(raw);
    } catch {
      plan = { reply: "Sorry sir, I could not process that.", steps: [] };
    }
    return json(sanitize(plan));
  },
};
