# JARVIS AI backend (Cloudflare Worker, free)

1. Get a Gemini API key: aistudio.google.com/app/apikey
2. dash.cloudflare.com > Workers & Pages > Create > Hello World > Deploy, then "Edit code".
   Delete everything, paste cloudflare-worker.js, click Deploy.
3. Worker > Settings > Variables and Secrets > add two SECRETS:
   GEMINI_API_KEY = your Gemini key
   APP_TOKEN      = a long random password you invent
   (optional variable GEMINI_MODEL if the default model name stops working)
4. Copy the worker URL (https://something.workers.dev).
5. In the app: Settings > AI brain: paste the URL and the same APP_TOKEN, tap Save.
