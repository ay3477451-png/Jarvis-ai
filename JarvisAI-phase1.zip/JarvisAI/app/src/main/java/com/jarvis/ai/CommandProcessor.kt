package com.jarvis.ai

import com.jarvis.ai.models.JarvisCommand
import java.util.Locale

/**
 * Turns a spoken sentence (English, Hindi or Hinglish) into a fixed, structured command.
 * Phase 2 adds Gemini as a fallback for sentences this rule-based parser cannot understand.
 */
class CommandProcessor {

    fun parse(raw: String): JarvisCommand {
        var text = normalize(raw)

        var hadWake = false
        WAKE_REGEX.find(text)?.let {
            hadWake = true
            text = text.substring(it.range.last + 1).trim()
        }
        if (text.isEmpty()) return if (hadWake) JarvisCommand.WakeOnly else JarvisCommand.Unknown(raw)

        if (text in STOP_WORDS) return JarvisCommand.Stop

        ACCESSIBILITY_COMMANDS.firstOrNull { (_, keys) -> keys.any { text.contains(it) } }
            ?.let { return JarvisCommand.NeedsAccessibility(it.first) }

        if (SETTINGS_WORDS.any { text.contains(it) }) return JarvisCommand.OpenSettings

        val tokens = text.split(" ").filter { it.isNotBlank() }

        if (tokens.any { it in OPEN_WORDS }) {
            val name = tokens.filterNot { it in OPEN_WORDS || it in OPEN_NOISE }.joinToString(" ")
            if (name.isBlank()) return JarvisCommand.Unknown(raw)
            return when {
                YOUTUBE_ALIASES.any { name.contains(it) } && !name.contains("music") ->
                    JarvisCommand.OpenApp("youtube", "YouTube")
                WHATSAPP_ALIASES.any { name.contains(it) } ->
                    JarvisCommand.OpenApp("whatsapp", "WhatsApp")
                else -> JarvisCommand.OpenApp(name, name)
            }
        }

        val isMusic = text.startsWith("play ") || text == "play" ||
            MUSIC_WORDS.any { text.contains(it) }
        if (isMusic) {
            val query = tokens.filterNot { it in MUSIC_NOISE }.joinToString(" ")
            return JarvisCommand.PlayMusic(query)
        }

        if (TIME_WORDS.any { text.contains(it) }) return JarvisCommand.TellTime

        return JarvisCommand.Unknown(raw)
    }

    private fun normalize(raw: String): String =
        raw.lowercase(Locale.ROOT)
            .replace(Regex("[.,!?।]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private companion object {
        val WAKE_REGEX = Regex(
            "^(?:hey|hi|hello|ok|okay|हे|हेलो|हैलो)?\\s*(?:jarvis|जार्विस|जारविस|जर्विस|जार्वीस)\\s*"
        )

        val STOP_WORDS = setOf("stop", "cancel", "ruko", "रुको", "रुक जाओ", "चुप", "chup")

        val ACCESSIBILITY_COMMANDS = listOf(
            "scroll down" to listOf("scroll down", "स्क्रॉल डाउन", "नीचे स्क्रॉल", "neeche scroll", "scroll neeche"),
            "scroll up" to listOf("scroll up", "स्क्रॉल अप", "ऊपर स्क्रॉल", "upar scroll", "scroll upar"),
            "go back" to listOf("go back", "पीछे जाओ", "वापस जाओ", "peeche jao", "back jao")
        )

        val SETTINGS_WORDS = listOf("settings", "सेटिंग", "setting kholo")
        val OPEN_WORDS = setOf("open", "launch", "kholo", "kholiye", "khol", "खोलो", "खोलिए", "खोलिये", "खोल")
        val OPEN_NOISE = setOf("please", "plz", "the", "app", "ऐप", "एप", "karo", "करो", "जी")

        val YOUTUBE_ALIASES = listOf("youtube", "you tube", "यूट्यूब", "यूटयूब", "यू ट्यूब")
        val WHATSAPP_ALIASES = listOf("whatsapp", "whats app", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सएप", "वाट्सएप", "व्हाट्स ऐप")

        val MUSIC_WORDS = listOf("music", "song", "गाना", "गाने", "संगीत", "gana", "gaana")
        val MUSIC_NOISE = setOf(
            "play", "music", "song", "songs", "the", "some", "me", "a", "for", "please",
            "गाना", "गाने", "संगीत", "बजाओ", "चलाओ", "सुनाओ", "bajao", "chalao", "sunao", "gana", "gaana"
        )

        val TIME_WORDS = listOf("time", "samay", "समय", "टाइम", "baje", "बजे")
    }
}
