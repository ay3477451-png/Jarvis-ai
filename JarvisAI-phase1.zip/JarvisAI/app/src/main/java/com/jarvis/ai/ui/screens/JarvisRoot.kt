package com.jarvis.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.ai.JarvisViewModel
import com.jarvis.ai.ui.theme.JarvisColors

enum class Tab(val label: String) {
    DASHBOARD("Dashboard"),
    SETTINGS("Settings"),
    PERMISSIONS("Permissions")
}

@Composable
fun JarvisRoot(
    vm: JarvisViewModel,
    micGranted: Boolean,
    onRequestMic: () -> Unit,
    onOpenAppSettings: () -> Unit
) {
    var tab by remember { mutableStateOf(Tab.DASHBOARD) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val level by vm.rms.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(JarvisColors.Bg, JarvisColors.DeepBlue)))
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = JarvisColors.Panel) {
                    Tab.values().forEach { t ->
                        val selected = t == tab
                        NavigationBarItem(
                            selected = selected,
                            onClick = { tab = t },
                            icon = {
                                Box(
                                    Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (selected) JarvisColors.Cyan else JarvisColors.CyanDim)
                                )
                            },
                            label = { Text(t.label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedTextColor = JarvisColors.Cyan,
                                unselectedTextColor = JarvisColors.CyanDim,
                                indicatorColor = JarvisColors.Cyan.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (tab) {
                    Tab.DASHBOARD -> DashboardScreen(
                        ui = ui,
                        level = level,
                        history = history,
                        onMic = { if (micGranted) vm.onMicClick() else onRequestMic() },
                        onEmergencyStop = vm::emergencyStop
                    )
                    Tab.SETTINGS -> SettingsScreen(
                        ui = ui,
                        onLanguage = vm::setLanguage,
                        onPitch = vm::setPitch,
                        onRate = vm::setSpeechRate,
                        onSaveVoice = vm::saveVoiceSettings,
                        onTestVoice = vm::testVoice,
                        onClearHistory = vm::clearHistory
                    )
                    Tab.PERMISSIONS -> PermissionsScreen(
                        micGranted = micGranted,
                        onRequestMic = onRequestMic,
                        onOpenAppSettings = onOpenAppSettings
                    )
                }
            }
        }
    }
}
