package com.jarvis.ai.models

data class JarvisUiState(
    val state: JarvisState = JarvisState.IDLE,
    val transcript: String = "",
    val response: String = "Systems online. Tap the reactor button and speak, sir.",
    val language: JarvisLanguage = JarvisLanguage.ENGLISH,
    val pitch: Float = 0.7f,
    val speechRate: Float = 0.9f
)
