package com.jarvis.ai

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.jarvis.ai.models.JarvisLanguage
import java.util.Locale

/**
 * Text-to-speech with a "deep male assistant" tuning: low pitch, slightly slow rate,
 * and a male-named offline voice when the device engine offers one.
 */
class TextToSpeechManager(context: Context) {

    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var doneCallback: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            val engine = tts
            if (status == TextToSpeech.SUCCESS && engine != null) {
                engine.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = finish()

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finish()

                    override fun onError(utteranceId: String?, errorCode: Int) = finish()
                })
                ready = true
            }
        }
    }

    /** Returns false if the engine is not ready or refused the request. */
    fun speak(text: String, language: JarvisLanguage, pitch: Float, rate: Float, onDone: () -> Unit): Boolean {
        val engine = tts
        if (!ready || engine == null) return false

        doneCallback = onDone
        engine.setLanguage(language.locale) // if data is missing the engine keeps its default voice
        pickMaleVoice(engine, language.locale)?.let { engine.voice = it }
        engine.setPitch(pitch)
        engine.setSpeechRate(rate)

        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.nanoTime()}")
        if (result == TextToSpeech.ERROR) {
            doneCallback = null
            return false
        }
        return true
    }

    fun stop() {
        doneCallback = null
        tts?.stop()
    }

    fun shutdown() {
        doneCallback = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }

    private fun finish() {
        val cb = doneCallback
        doneCallback = null
        cb?.invoke()
    }

    private fun pickMaleVoice(engine: TextToSpeech, locale: Locale): Voice? =
        engine.voices
            ?.filter {
                it.locale.language == locale.language &&
                    !it.isNetworkConnectionRequired &&
                    it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true
            }
            ?.firstOrNull {
                val n = it.name.lowercase()
                n.contains("male") && !n.contains("female")
            }
}
