package com.jarvis.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.ui.components.HoloPanel
import com.jarvis.ai.ui.theme.JarvisColors

@Composable
fun PermissionsScreen(
    micGranted: Boolean,
    onRequestMic: () -> Unit,
    onOpenAppSettings: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("PERMISSIONS", color = JarvisColors.Cyan, fontSize = 20.sp, letterSpacing = 4.sp)
        Text("You stay in control. Nothing is enabled without your approval.", color = JarvisColors.CyanDim, fontSize = 12.sp)

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Microphone", color = JarvisColors.Text, fontSize = 15.sp)
            Text(
                if (micGranted) "GRANTED" else "NOT GRANTED",
                color = if (micGranted) JarvisColors.Cyan else JarvisColors.Amber,
                fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 4.dp)
            )
            Text(
                "Used only while you tap the microphone button, to hear your command. " +
                    "Speech is processed by your phone's speech service (Google's service for most devices).",
                color = JarvisColors.CyanDim, fontSize = 12.sp
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!micGranted) Button(onClick = onRequestMic) { Text("Grant") }
                OutlinedButton(onClick = onOpenAppSettings) { Text("App settings") }
            }
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Accessibility service", color = JarvisColors.Text, fontSize = 15.sp)
            Text("COMING IN PHASE 2", color = JarvisColors.Amber, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 4.dp))
            Text(
                "Needed for scroll, tap, swipe and back commands. You will enable it yourself in Android " +
                    "Settings, and can switch it off at any time. JARVIS cannot turn it on by itself.",
                color = JarvisColors.CyanDim, fontSize = 12.sp
            )
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Wake word \"Hey Jarvis\"", color = JarvisColors.Text, fontSize = 15.sp)
            Text("COMING IN PHASE 3", color = JarvisColors.Amber, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 4.dp))
            Text(
                "Always-on listening needs a visible foreground-service notification. Android 14+ blocks " +
                    "starting microphone services from the background, and battery savers can stop it. " +
                    "For now, tap the microphone button, or say \"Hey Jarvis, ...\" as part of a command.",
                color = JarvisColors.CyanDim, fontSize = 12.sp
            )
        }
    }
}
