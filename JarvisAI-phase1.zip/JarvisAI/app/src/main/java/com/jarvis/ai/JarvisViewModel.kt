package com.jarvis.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.database.HistoryEntity
import com.jarvis.ai.models.JarvisCommand
import com.jarvis.ai.models.JarvisLanguage
import com.jarvis.ai.models.JarvisState
import com.jarvis.ai.models.JarvisUiState
import com.jarvis.ai.utils.TimeUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private data class ExecResult(val message: String, val success: Boolean)

    private val repo = (app as JarvisApp).repository
    private val voice = VoiceRecognitionManager(app)
    private val tts = TextToSpeechManager(app)
    private val launcher = AppLauncher(app)
    private val processor = CommandProcessor()

    private val _ui = MutableStateFlow(JarvisUiState())
    val ui: StateFlow<JarvisUiState> = _ui.asStateFlow()
    val rms: StateFlow<Float> = voice.rms
    val history: StateFlow<List<HistoryEntity>> =
        repo.history.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private var job: Job? = null

    init {
        viewModelScope.launch {
            val lang = repo.getPref(KEY_LANG)
                ?.let { saved -> JarvisLanguage.values().firstOrNull { it.name == saved } }
                ?: JarvisLanguage.ENGLISH
            val pitch = repo.getPref(KEY_PITCH)?.toFloatOrNull() ?: 0.7f
            val rate = repo.getPref(KEY_RATE)?.toFloatOrNull() ?: 0.9f
            _ui.update { it.copy(language = lang, pitch = pitch, speechRate = rate) }
        }
    }

    // ---------- user actions ----------

    fun onMicClick() {
        when (_ui.value.state) {
            JarvisState.LISTENING -> voice.stop()
            JarvisState.IDLE -> startListening()
            JarvisState.SPEAKING -> {
                tts.stop()
                startListening()
            }
            else -> Unit // busy thinking / executing
        }
    }

    /** Emergency stop: cancels listening, speech and any running command immediately. */
    fun emergencyStop() {
        job?.cancel()
        voice.cancel()
        tts.stop()
        _ui.update { it.copy(state = JarvisState.IDLE, response = "Emergency stop engaged. All activity halted, sir.") }
    }

    fun setLanguage(language: JarvisLanguage) {
        _ui.update { it.copy(language = language) }
        viewModelScope.launch { repo.setPref(KEY_LANG, language.name) }
    }

    fun setPitch(value: Float) = _ui.update { it.copy(pitch = value) }
    fun setSpeechRate(value: Float) = _ui.update { it.copy(speechRate = value) }

    fun saveVoiceSettings() {
        val s = _ui.value
        viewModelScope.launch {
            repo.setPref(KEY_PITCH, s.pitch.toString())
            repo.setPref(KEY_RATE, s.speechRate.toString())
        }
    }

    fun testVoice() {
        val lang = _ui.value.language
        respond(tr(lang, "Good evening, sir. All systems are operational.", "नमस्कार सर, सभी सिस्टम सक्रिय हैं।"))
    }

    fun clearHistory() {
        viewModelScope.launch { repo.clearHistory() }
    }

    // ---------- pipeline: listen -> think -> execute -> speak ----------

    private fun startListening() {
        if (!voice.isAvailable()) {
            _ui.update { it.copy(response = "No speech recognition service is available on this phone.") }
            return
        }
        tts.stop()
        _ui.update { it.copy(state = JarvisState.LISTENING, transcript = "") }
        voice.start(_ui.value.language, object : VoiceRecognitionManager.Listener {
            override fun onPartial(text: String) {
                _ui.update { it.copy(transcript = text) }
            }

            override fun onFinal(text: String) = handleSpoken(text)

            override fun onError(message: String) {
                _ui.update { it.copy(state = JarvisState.IDLE, response = message) }
            }
        })
    }

    private fun handleSpoken(text: String) {
        job?.cancel()
        job = viewModelScope.launch {
            _ui.update { it.copy(state = JarvisState.THINKING, transcript = text) }
            val lang = _ui.value.language
            val command = processor.parse(text)
            _ui.update { it.copy(state = JarvisState.EXECUTING) }
            val result = execute(command, lang)
            repo.addHistory(text, result.message, result.success)
            respond(result.message)
        }
    }

    private fun execute(cmd: JarvisCommand, lang: JarvisLanguage): ExecResult = when (cmd) {
        JarvisCommand.WakeOnly ->
            ExecResult(tr(lang, "Yes, sir? I'm listening.", "जी सर, मैं सुन रहा हूँ।"), true)

        JarvisCommand.TellTime -> ExecResult(TimeUtils.spokenTime(lang), true)

        JarvisCommand.Stop ->
            ExecResult(tr(lang, "Standing by, sir.", "ठीक है सर, मैं रुक गया।"), true)

        JarvisCommand.OpenSettings ->
            if (launcher.openSettings()) ExecResult(tr(lang, "Opening settings.", "सेटिंग्स खोल रहा हूँ।"), true)
            else ExecResult(tr(lang, "I couldn't open settings.", "मैं सेटिंग्स नहीं खोल पाया।"), false)

        is JarvisCommand.OpenApp -> {
            val label = launcher.openByName(cmd.name)
            if (label != null) ExecResult(tr(lang, "Opening $label.", "$label खोल रहा हूँ।"), true)
            else ExecResult(
                tr(lang, "I couldn't find ${cmd.display} on this phone, sir.", "सर, मुझे इस फोन पर ${cmd.display} नहीं मिला।"),
                false
            )
        }

        is JarvisCommand.PlayMusic -> {
            if (launcher.playMusic(cmd.query)) {
                if (cmd.query.isBlank()) ExecResult(tr(lang, "Opening your music player.", "आपका म्यूज़िक प्लेयर खोल रहा हूँ।"), true)
                else ExecResult(tr(lang, "Searching for ${cmd.query}.", "${cmd.query} खोज रहा हूँ।"), true)
            } else ExecResult(tr(lang, "I couldn't find a music app, sir.", "सर, मुझे कोई म्यूज़िक ऐप नहीं मिला।"), false)
        }

        is JarvisCommand.NeedsAccessibility -> ExecResult(
            tr(
                lang,
                "'${cmd.action}' needs the Accessibility service, which arrives in Phase 2, sir.",
                "'${cmd.action}' के लिए एक्सेसिबिलिटी सर्विस चाहिए, जो फेज़ 2 में आएगी।"
            ),
            false
        )

        is JarvisCommand.Unknown -> ExecResult(
            tr(
                lang,
                "I didn't understand \"${cmd.heard}\", sir. Try 'open YouTube', 'play music' or 'tell me the time'.",
                "सर, मैं \"${cmd.heard}\" समझ नहीं पाया। कहें 'यूट्यूब खोलो', 'गाना बजाओ' या 'समय बताओ'।"
            ),
            false
        )
    }

    private fun respond(message: String) {
        val s = _ui.value
        _ui.update { it.copy(state = JarvisState.SPEAKING, response = message) }
        val started = tts.speak(message, s.language, s.pitch, s.speechRate) {
            _ui.update { cur -> if (cur.state == JarvisState.SPEAKING) cur.copy(state = JarvisState.IDLE) else cur }
        }
        if (!started) _ui.update { it.copy(state = JarvisState.IDLE) }
    }

    private fun tr(lang: JarvisLanguage, en: String, hi: String) =
        if (lang == JarvisLanguage.HINDI) hi else en

    override fun onCleared() {
        voice.destroy()
        tts.shutdown()
        super.onCleared()
    }

    private companion object {
        const val KEY_LANG = "language"
        const val KEY_PITCH = "tts_pitch"
        const val KEY_RATE = "tts_rate"
    }
}
