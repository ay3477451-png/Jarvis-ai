package com.jarvis.ai.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.models.JarvisLanguage
import com.jarvis.ai.models.JarvisUiState
import com.jarvis.ai.ui.components.HoloPanel
import com.jarvis.ai.ui.theme.JarvisColors

@Composable
fun SettingsScreen(
    ui: JarvisUiState,
    onLanguage: (JarvisLanguage) -> Unit,
    onPitch: (Float) -> Unit,
    onRate: (Float) -> Unit,
    onSaveVoice: () -> Unit,
    onTestVoice: () -> Unit,
    onClearHistory: () -> Unit
) {
    var confirmClear by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("SETTINGS", color = JarvisColors.Cyan, fontSize = 20.sp, letterSpacing = 4.sp)

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Voice recognition language", color = JarvisColors.Text, fontSize = 14.sp)
            Text(
                "Hindi mode also understands English words (Hinglish). Commands work in both languages.",
                color = JarvisColors.CyanDim, fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisLanguage.values().forEach { lang ->
                    if (lang == ui.language) {
                        Button(onClick = { onLanguage(lang) }) { Text(lang.label) }
                    } else {
                        OutlinedButton(onClick = { onLanguage(lang) }) { Text(lang.label) }
                    }
                }
            }
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("JARVIS voice", color = JarvisColors.Text, fontSize = 14.sp)
            Text("Pitch (lower = deeper): ${"%.2f".format(ui.pitch)}", color = JarvisColors.CyanDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            Slider(value = ui.pitch, onValueChange = onPitch, valueRange = 0.5f..1.2f, onValueChangeFinished = onSaveVoice)
            Text("Speed: ${"%.2f".format(ui.speechRate)}", color = JarvisColors.CyanDim, fontSize = 12.sp)
            Slider(value = ui.speechRate, onValueChange = onRate, valueRange = 0.6f..1.2f, onValueChangeFinished = onSaveVoice)
            OutlinedButton(onClick = onTestVoice) { Text("Test voice") }
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Data", color = JarvisColors.Text, fontSize = 14.sp)
            OutlinedButton(
                onClick = { confirmClear = true },
                border = BorderStroke(1.dp, JarvisColors.Red),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisColors.Red),
                modifier = Modifier.padding(top = 8.dp)
            ) { Text("Clear command history") }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Delete command history?") },
            text = { Text("This permanently removes all saved commands from this phone.") },
            confirmButton = {
                TextButton(onClick = { confirmClear = false; onClearHistory() }) {
                    Text("Delete", color = JarvisColors.Red)
                }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}
