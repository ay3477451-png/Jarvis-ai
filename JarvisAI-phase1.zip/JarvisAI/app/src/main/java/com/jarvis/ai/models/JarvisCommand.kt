package com.jarvis.ai.models

/** Structured command produced from a spoken sentence. Never executes code, only these fixed types. */
sealed interface JarvisCommand {
    data object WakeOnly : JarvisCommand
    data object TellTime : JarvisCommand
    data object OpenSettings : JarvisCommand
    data object Stop : JarvisCommand
    data class OpenApp(val name: String, val display: String) : JarvisCommand
    data class PlayMusic(val query: String) : JarvisCommand
    /** Scroll / back / home etc. Needs the AccessibilityService (Phase 2). */
    data class NeedsAccessibility(val action: String) : JarvisCommand
    data class Unknown(val heard: String) : JarvisCommand
}
