# JARVIS AI (Android) - Phase 1

Phase 1 = project setup, futuristic dashboard, Hindi/English voice recognition, spoken replies,
Room history + settings, permissions page, emergency stop.

NOTE: this project was written without running Gradle (no network in the authoring sandbox).
Build it and send any compiler error to the assistant; it will be fixed in the next reply.

## Package layout (com.jarvis.ai)
MainActivity.kt, JarvisViewModel.kt, VoiceRecognitionManager.kt, TextToSpeechManager.kt,
CommandProcessor.kt, AppLauncher.kt, JarvisApp.kt
models/    JarvisState, JarvisLanguage, JarvisUiState, JarvisCommand
database/  Entities, Daos, JarvisDatabase, JarvisRepository (Room)
ui/theme, ui/components (ArcReactor, VoiceWaveform, MicButton ...), ui/screens (Dashboard, Settings, Permissions, Root)
utils/     TimeUtils, PermissionUtils

Deferred to later phases: AIManager.kt, JarvisAccessibilityService.kt, YouTubeController.kt, Services/ (wake word).

## Build on a PC (recommended)
1. Install Android Studio (Koala or newer) with JDK 17.
2. File > Open > select the JarvisAI folder. Let Gradle sync.
3. Run on a phone (USB debugging) or Build > Build APK(s).
   CLI: `gradle wrapper` once (needs Gradle installed), then `./gradlew assembleDebug`.
   APK: app/build/outputs/apk/debug/app-debug.apk

## Build in Termux (experimental)
Android's official build tools target x86 Linux, so on-device builds need ARM tool builds.
1. `pkg update && pkg install openjdk-17 gradle git wget unzip aapt2`
2. Install an ARM64 Android SDK (platforms;android-34, build-tools;34.0.0), e.g. a community
   "termux android sdk" package, then:
   `export ANDROID_HOME=$HOME/android-sdk`
   `echo "sdk.dir=$ANDROID_HOME" > local.properties`
3. In gradle.properties uncomment the aapt2FromMavenOverride line and set it to `$(which aapt2)`.
4. `cd JarvisAI && gradle assembleDebug --no-daemon`
5. Copy app/build/outputs/apk/debug/app-debug.apk to /sdcard/Download and install it.
If this is too heavy for your phone, AndroidIDE (an on-device Android IDE app) can open this project.

## Using it
Grant the microphone permission, tap the mic button, and say e.g.
"Hey Jarvis, open YouTube", "play music", "tell me the time", "open settings",
"यूट्यूब खोलो", "समय बताओ", "गाना बजाओ". Scroll/back say "needs Accessibility (Phase 2)".
Hindi/English is chosen in Settings (Android's recognizer can't auto-detect language).
Hindi speech and voice may need Google's Hindi voice data installed on the phone.
"Deep male" voice = low pitch + a male offline voice if the device has one; tune in Settings.
