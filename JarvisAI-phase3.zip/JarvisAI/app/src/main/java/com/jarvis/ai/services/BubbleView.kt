package com.jarvis.ai.services

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import com.jarvis.ai.models.JarvisState
import kotlin.math.sin

/** Small animated arc-reactor drawn with plain Canvas, used as the floating bubble. */
class BubbleView(context: Context) : View(context) {

    var state: JarvisState = JarvisState.IDLE
        set(value) {
            if (field != value) {
                field = value
                animator.duration = durationFor(value)
                invalidate()
            }
        }

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var angle = 0f

    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = durationFor(JarvisState.IDLE)
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            angle = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = (60 * density).toInt()
        setMeasuredDimension(size, size)
    }

    override fun onDraw(canvas: Canvas) {
        val c = width / 2f
        val r = c - 2 * density
        val color = if (state == JarvisState.THINKING) AMBER else CYAN

        paint.style = Paint.Style.FILL
        paint.color = Color.argb(230, 2, 6, 15)
        canvas.drawCircle(c, c, r, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2 * density
        paint.color = color
        paint.alpha = 140
        canvas.drawCircle(c, c, r, paint)

        paint.alpha = 255
        paint.strokeWidth = 4 * density
        paint.strokeCap = Paint.Cap.ROUND
        rect.set(c - r * 0.78f, c - r * 0.78f, c + r * 0.78f, c + r * 0.78f)
        for (i in 0 until 3) canvas.drawArc(rect, angle + i * 120f, 60f, false, paint)

        val pulse = 1f + 0.12f * sin(Math.toRadians(angle * 4.0)).toFloat()
        paint.style = Paint.Style.FILL
        paint.color = color
        canvas.drawCircle(c, c, r * 0.30f * pulse, paint)
        paint.color = Color.WHITE
        paint.alpha = 200
        canvas.drawCircle(c, c, r * 0.14f * pulse, paint)
    }

    private fun durationFor(s: JarvisState): Long = when (s) {
        JarvisState.IDLE -> 6000L
        JarvisState.LISTENING -> 2500L
        JarvisState.THINKING -> 1200L
        JarvisState.EXECUTING -> 1800L
        JarvisState.SPEAKING -> 2200L
    }

    private companion object {
        val CYAN = Color.parseColor("#00E5FF")
        val AMBER = Color.parseColor("#FFB300")
    }
}
