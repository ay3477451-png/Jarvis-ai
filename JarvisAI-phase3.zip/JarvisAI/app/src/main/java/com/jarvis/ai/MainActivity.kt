package com.jarvis.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.jarvis.ai.services.JarvisOverlayService
import com.jarvis.ai.ui.screens.JarvisRoot
import com.jarvis.ai.ui.theme.JarvisTheme
import com.jarvis.ai.utils.PermissionUtils
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()
    private val engine: JarvisEngine get() = viewModel.engine

    private var micGranted by mutableStateOf(false)
    private var overlayGranted by mutableStateOf(false)

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            micGranted = granted
        }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            startBubble() // the bubble works even if the notification is hidden
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        micGranted = PermissionUtils.hasMicrophone(this)
        overlayGranted = Settings.canDrawOverlays(this)

        // When a screen action must hit another app, JARVIS steps aside first.
        lifecycleScope.launch {
            engine.moveToBack.collect { moveTaskToBack(true) }
        }

        setContent {
            JarvisTheme {
                JarvisRoot(
                    vm = engine,
                    micGranted = micGranted,
                    overlayGranted = overlayGranted,
                    onRequestMic = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                    onOpenAppSettings = {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                        )
                    },
                    onOpenAccessibilitySettings = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                    onRequestOverlay = {
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                        )
                    },
                    onToggleBubble = ::toggleBubble
                )
            }
        }
    }

    private fun toggleBubble() {
        if (JarvisOverlayService.running.value) {
            stopService(Intent(this, JarvisOverlayService::class.java))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!PermissionUtils.hasMicrophone(this)) {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startBubble()
        }
    }

    private fun startBubble() {
        ContextCompat.startForegroundService(this, Intent(this, JarvisOverlayService::class.java))
    }

    override fun onStart() {
        super.onStart()
        engine.appInForeground = true
    }

    override fun onStop() {
        engine.appInForeground = false
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        micGranted = PermissionUtils.hasMicrophone(this)
        overlayGranted = Settings.canDrawOverlays(this)
        engine.refreshAccessibility()
    }
}
