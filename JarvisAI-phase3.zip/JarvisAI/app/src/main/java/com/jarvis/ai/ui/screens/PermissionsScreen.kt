package com.jarvis.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.ui.components.HoloPanel
import com.jarvis.ai.ui.theme.JarvisColors

@Composable
fun PermissionsScreen(
    micGranted: Boolean,
    accessibilityEnabled: Boolean,
    overlayGranted: Boolean,
    bubbleRunning: Boolean,
    onRequestMic: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onRequestOverlay: () -> Unit,
    onToggleBubble: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("PERMISSIONS", color = JarvisColors.Cyan, fontSize = 20.sp, letterSpacing = 4.sp)
        Text("You stay in control. Nothing is enabled without your approval.", color = JarvisColors.CyanDim, fontSize = 12.sp)

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Microphone", color = JarvisColors.Text, fontSize = 15.sp)
            Text(
                if (micGranted) "GRANTED" else "NOT GRANTED",
                color = if (micGranted) JarvisColors.Cyan else JarvisColors.Amber,
                fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 4.dp)
            )
            Text(
                "Used only while you tap the microphone button, to hear your command. " +
                    "Speech is processed by your phone's speech service (Google's service for most devices).",
                color = JarvisColors.CyanDim, fontSize = 12.sp
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!micGranted) Button(onClick = onRequestMic) { Text("Grant") }
                OutlinedButton(onClick = onOpenAppSettings) { Text("App settings") }
            }
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Floating JARVIS bubble", color = JarvisColors.Text, fontSize = 15.sp)
            Text(
                if (bubbleRunning) "RUNNING" else "OFF",
                color = if (bubbleRunning) JarvisColors.Cyan else JarvisColors.Amber,
                fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 4.dp)
            )
            Text(
                "A small reactor that floats over any app. Tap it to talk, hold it for emergency stop, " +
                    "drag it to move. It needs \"Display over other apps\" and shows a notification " +
                    "while running. It starts only when you tap Start, and you can turn it off anytime.",
                color = JarvisColors.CyanDim, fontSize = 12.sp
            )
            Text(
                "Display over other apps: ${if (overlayGranted) "ALLOWED" else "NOT ALLOWED"}",
                color = if (overlayGranted) JarvisColors.Cyan else JarvisColors.Amber,
                fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!overlayGranted) Button(onClick = onRequestOverlay) { Text("Allow") }
                Button(onClick = onToggleBubble) { Text(if (bubbleRunning) "Stop bubble" else "Start bubble") }
            }
            Text(
                "Tip: on Realme / Oppo / Vivo phones also allow Auto-start and set battery usage to " +
                    "\"No restrictions\" for JARVIS AI, or the system may close the bubble.",
                color = JarvisColors.CyanDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Accessibility service", color = JarvisColors.Text, fontSize = 15.sp)
            Text(
                if (accessibilityEnabled) "ENABLED" else "NOT ENABLED",
                color = if (accessibilityEnabled) JarvisColors.Cyan else JarvisColors.Amber,
                fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 4.dp)
            )
            Text(
                "Needed for scroll, back, tap, typing and reading the screen. It works only when you give a " +
                    "command. Passwords are never read or filled. Only you can turn it on or off.",
                color = JarvisColors.CyanDim, fontSize = 12.sp
            )
            Text(
                "Steps: tap the button, open JARVIS AI in the list, switch it on. If Android says " +
                    "\"Restricted setting\": App settings > top-right three dots > Allow restricted settings, then try again.",
                color = JarvisColors.CyanDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOpenAccessibilitySettings) { Text("Open Accessibility settings") }
            }
            Row(Modifier.padding(top = 4.dp)) {
                OutlinedButton(onClick = onOpenAppSettings) { Text("App settings") }
            }
        }

        HoloPanel(Modifier.fillMaxWidth()) {
            Text("Wake word \"Hey Jarvis\"", color = JarvisColors.Text, fontSize = 15.sp)
            Text("COMING LATER", color = JarvisColors.Amber, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.padding(vertical = 4.dp))
            Text(
                "Always-on listening needs a visible foreground-service notification. Android 14+ blocks " +
                    "starting microphone services from the background, and battery savers can stop it. " +
                    "For now, use the floating bubble or the microphone button, or say \"Hey Jarvis, ...\" as part of a command.",
                color = JarvisColors.CyanDim, fontSize = 12.sp
            )
        }
    }
}
