package com.jarvis.ai

import android.app.Application
import com.jarvis.ai.database.JarvisDatabase
import com.jarvis.ai.database.JarvisRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class JarvisApp : Application() {
    val database by lazy { JarvisDatabase.build(this) }
    val repository by lazy { JarvisRepository(database.historyDao(), database.prefDao()) }
    val engine by lazy { JarvisEngine(this, CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)) }
}
