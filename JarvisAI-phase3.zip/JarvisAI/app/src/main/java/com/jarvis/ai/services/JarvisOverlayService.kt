package com.jarvis.ai.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.jarvis.ai.JarvisApp
import com.jarvis.ai.JarvisEngine
import com.jarvis.ai.MainActivity
import com.jarvis.ai.models.JarvisState
import com.jarvis.ai.models.JarvisUiState
import com.jarvis.ai.models.PendingConfirm
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Floating JARVIS bubble. Runs as a visible foreground service (a notification is always shown).
 * Tap = talk / stop listening, long-press = emergency stop, drag = move.
 * It starts only when the user taps "Start bubble" inside the app.
 */
class JarvisOverlayService : Service() {

    companion object {
        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()

        const val ACTION_STOP = "com.jarvis.ai.action.STOP_BUBBLE"
        const val ACTION_EMERGENCY = "com.jarvis.ai.action.EMERGENCY_STOP"
        private const val CHANNEL_ID = "jarvis_bubble"
        private const val NOTIFICATION_ID = 42
    }

    private lateinit var engine: JarvisEngine
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var scope: CoroutineScope? = null

    private var container: LinearLayout? = null
    private var bubble: BubbleView? = null
    private var label: TextView? = null
    private var confirmCard: LinearLayout? = null
    private var interacted = false

    private val hideLabel = Runnable {
        label?.visibility = View.GONE
        interacted = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        engine = (application as JarvisApp).engine
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_EMERGENCY -> engine.emergencyStop()
        }

        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (container == null) {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
            addBubble()
            val s = CoroutineScope(SupervisorJob() + Dispatchers.Main)
            scope = s
            s.launch { engine.ui.collect { render(it) } }
            _running.value = true
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        scope?.cancel()
        scope = null
        hideConfirm()
        container?.let { runCatching { wm.removeView(it) } }
        container = null
        _running.value = false
        super.onDestroy()
    }

    // ---------- foreground notification ----------

    private fun startAsForeground(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "JARVIS bubble", NotificationManager.IMPORTANCE_LOW)
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        fun serviceIntent(action: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, JarvisOverlayService::class.java).setAction(action), flags
        )
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS is active")
            .setContentText("Tap the floating bubble to talk")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Emergency stop", serviceIntent(ACTION_EMERGENCY, 2))
            .addAction(0, "Turn off", serviceIntent(ACTION_STOP, 1))
            .build()

        return try {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- bubble window ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addBubble() {
        val bubbleView = BubbleView(this)
        val labelView = TextView(this).apply {
            visibility = View.GONE
            setTextColor(Color.WHITE)
            textSize = 12f
            maxWidth = dp(220)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.argb(204, 2, 6, 15))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.argb(136, 0, 229, 255))
            }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(bubbleView)
            addView(
                labelView,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(4) }
            )
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, // never steals focus from the app underneath
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - dp(80)
            y = dp(220)
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        box.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0f
            var startY = 0f
            var originX = 0
            var originY = 0
            var downTime = 0L
            var dragging = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = e.rawX
                        startY = e.rawY
                        originX = lp.x
                        originY = lp.y
                        downTime = SystemClock.uptimeMillis()
                        dragging = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - startX
                        val dy = e.rawY - startY
                        if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                        if (dragging) {
                            lp.x = originX + dx.toInt()
                            lp.y = originY + dy.toInt()
                            wm.updateViewLayout(box, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!dragging) {
                            if (SystemClock.uptimeMillis() - downTime >= 600) engine.emergencyStop()
                            else engine.onMicClick()
                        }
                    }
                }
                return true
            }
        })

        wm.addView(box, lp)
        container = box
        bubble = bubbleView
        label = labelView
    }

    private fun render(ui: JarvisUiState) {
        bubble?.state = ui.state
        if (ui.state != JarvisState.IDLE) interacted = true

        val text = when (ui.state) {
            JarvisState.LISTENING -> ui.transcript.ifBlank { "Listening…" }
            JarvisState.THINKING -> ui.transcript.ifBlank { "Thinking…" }
            JarvisState.EXECUTING -> "Working…"
            JarvisState.SPEAKING, JarvisState.IDLE -> if (interacted) ui.response else ""
        }
        handler.removeCallbacks(hideLabel)
        label?.text = text
        label?.visibility = if (text.isBlank()) View.GONE else View.VISIBLE
        if (ui.state == JarvisState.IDLE && text.isNotBlank()) handler.postDelayed(hideLabel, 3500)

        val pending = ui.pendingConfirm
        if (pending != null) showConfirm(pending) else hideConfirm()
    }

    // ---------- confirmation card (for sensitive actions started from the bubble) ----------

    private fun showConfirm(p: PendingConfirm) {
        if (confirmCard != null) return

        val message = TextView(this).apply {
            text = "JARVIS wants to ${p.description}. Allow?"
            setTextColor(Color.WHITE)
            textSize = 15f
        }
        val allow = Button(this).apply {
            text = "Allow"
            setOnClickListener { engine.confirmPending() }
        }
        val cancel = Button(this).apply {
            text = "Cancel"
            setTextColor(Color.parseColor("#FF3D4D"))
            setOnClickListener { engine.cancelPending() }
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            addView(cancel)
            addView(allow)
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(240, 7, 20, 43))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.parseColor("#00E5FF"))
            }
            addView(message)
            addView(buttons)
        }

        val width = minOf(resources.displayMetrics.widthPixels - dp(32), dp(360))
        val lp = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(120)
        }
        wm.addView(card, lp)
        confirmCard = card
    }

    private fun hideConfirm() {
        confirmCard?.let { runCatching { wm.removeView(it) } }
        confirmCard = null
    }
}
