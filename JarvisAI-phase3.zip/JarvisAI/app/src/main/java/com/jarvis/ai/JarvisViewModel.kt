package com.jarvis.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel

/** Holds the shared JarvisEngine so the screens and the floating bubble use the same brain. */
class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    val engine: JarvisEngine = (app as JarvisApp).engine
}
